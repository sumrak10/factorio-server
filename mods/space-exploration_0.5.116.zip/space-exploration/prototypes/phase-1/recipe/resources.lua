local data_util = require("data_util")
local RecipeTints = require("prototypes/recipe-tints")

data:extend({
  -- pulverising
  {
    type = "recipe",
    category = "pulverising",
    name = data_util.mod_prefix .. "beryllium-ore-crushed",
    results = {
      {name = data_util.mod_prefix .. "beryllium-ore-crushed", amount = 1} -- 2
    },
    energy_required = 1,
    ingredients = {
      {name = data_util.mod_prefix .. "beryllium-ore", amount = 2}
    },
    enabled = false,
    always_show_made_in = true,
  },
  {
    type = "recipe",
    category = "chemistry",
    name = data_util.mod_prefix .. "beryllium-sulfate",
    main_product = data_util.mod_prefix .. "beryllium-sulfate",
    results = {
      {name = data_util.mod_prefix .. "beryllium-sulfate", amount = 1}, -- 4
      {name = "sand", probability = 0.5, amount_min = 1, amount_max = 1,},
      {type = "fluid", name = "water", amount = 1, catalyst_amount = 1},
    },
    energy_required = 2,
    ingredients = {
      {type = "fluid", name="sulfuric-acid", amount = 2},
      {name = data_util.mod_prefix .. "beryllium-ore-crushed", amount = 2}
    },
    enabled = false,
    always_show_made_in = true,
    crafting_machine_tint = RecipeTints.beryllium_tint,
  },
  {
    type = "recipe",
    category = "chemistry",
    name = data_util.mod_prefix .. "beryllium-hydroxide",
    main_product = data_util.mod_prefix .. "beryllium-hydroxide",
    results = {
      {type = "fluid", name = data_util.mod_prefix .. "beryllium-hydroxide", amount = 200}, --1
    },
    energy_required = 30,
    ingredients = {
      {name = data_util.mod_prefix .. "cryonite-rod", amount = 1},
      {type = "fluid", name="water", amount = 150, catalyst_amount = 150},
      {name = data_util.mod_prefix .. "beryllium-sulfate", amount = 50}
    },
    subgroup = "fluid-recipes",
    enabled = false,
    always_show_made_in = true,
    crafting_machine_tint = RecipeTints.beryllium_tint,
  },
  {
    type = "recipe",
    category = "chemistry",
    name = data_util.mod_prefix .. "beryllium-powder",
    main_product = data_util.mod_prefix .. "beryllium-powder",
    results = {
      {name = data_util.mod_prefix .. "beryllium-powder", amount = 1}, -- 2
      {type = "fluid", name = "water", amount = 1, catalyst_amount = 1},
    },
    energy_required = 1,
    ingredients = {
      {type = "fluid", name = data_util.mod_prefix .. "beryllium-hydroxide", amount = 2},
    },
    enabled = false,
    always_show_made_in = true,
    crafting_machine_tint = RecipeTints.beryllium_tint,
  },
  {
    type = "recipe",
    category = "smelting",
    name = data_util.mod_prefix .. "beryllium-ingot",
    results = {
      {name = data_util.mod_prefix .. "beryllium-ingot", amount = 1}, -- 20
    },
    energy_required = 40,
    ingredients = {
      {name = data_util.mod_prefix .. "beryllium-powder", amount = 10},
    },
    enabled = false,
    always_show_made_in = true,
  },
  {
    type = "recipe",
    category = "crafting",
    name = data_util.mod_prefix .. "beryllium-plate",
    results = {
      {name = data_util.mod_prefix .. "beryllium-plate", amount = 4}, -- 5
    },
    energy_required = 8,
    ingredients = {
      {name = data_util.mod_prefix .. "beryllium-ingot", amount = 1}
    },
    enabled = false,
    always_show_made_in = true,
  },


  {
    type = "recipe",
    category = "pulverising",
    name = data_util.mod_prefix .. "cryonite-crushed",
    results = {
      {name = data_util.mod_prefix .. "cryonite-crushed", amount = 1}
    },
    energy_required = 0.5,
    ingredients = {
      {name = data_util.mod_prefix .. "cryonite", amount = 2}
    },
    enabled = false,
    always_show_made_in = true,
  },
  {
    type = "recipe",
    category = "pressure-washing",
    name = data_util.mod_prefix .. "cryonite-washed",
    main_product = data_util.mod_prefix .. "cryonite-washed",
    results = {
      {name = data_util.mod_prefix .. "cryonite-washed", amount = 2},
      {name = "stone", amount_min = 1, amount_max = 1, probability = 0.25},
      {type = "fluid", name="water", amount = 4, catalyst_amount = 4},
    },
    energy_required = 1,
    ingredients = {
      {type = "fluid", name="water", amount = 6, catalyst_amount = 6},
      {name = data_util.mod_prefix .. "cryonite-crushed", amount = 2}
    },
    enabled = false,
    always_show_made_in = true,
    crafting_machine_tint = RecipeTints.cryonite_tint,
  },
  {
    type = "recipe",
    category = "smelting",
    name = data_util.mod_prefix .. "cryonite-rod",
    results = {
      {name = data_util.mod_prefix .. "cryonite-rod", amount = 1},
    },
    energy_required = 5,
    ingredients = {
      {name = data_util.mod_prefix .. "cryonite-washed", amount = 1}
    },
    enabled = false,
    always_show_made_in = true,
  },
  {
    type = "recipe",
    category = "chemistry",
    name = data_util.mod_prefix .. "cryonite-ion-exchange-beads",
    results = {
      {name = data_util.mod_prefix .. "cryonite-ion-exchange-beads", amount = 10},
    },
    energy_required = 10,
    ingredients = {
      {name = data_util.mod_prefix .. "cryonite-rod", amount = 1},
      {name = "plastic-bar", amount = 1},
      {type = "fluid", name = "sulfuric-acid", amount = 5},
      {type = "fluid", name = "steam", amount = 5},
    },
    crafting_machine_tint = RecipeTints.cryonite_tint,
    enabled = false,
    always_show_made_in = true,
  },
  {
    type = "recipe",
    category = "chemistry",
    name = data_util.mod_prefix .. "cryonite-lubricant",
    results = {
      {type = "fluid", name = "lubricant", amount = 10},
    },
    energy_required = 5,
    ingredients = {
      {type = "fluid", name = data_util.mod_prefix .. "cryonite-slush", amount = 10},
      {type = "fluid", name = "heavy-oil", amount = 1},
    },
    icons = data_util.sub_icons(data.raw.fluid["lubricant"].icon,
                                data.raw.fluid[data_util.mod_prefix .. "cryonite-slush"].icon),
    crafting_machine_tint = data.raw["recipe"]["lubricant"].crafting_machine_tint,
    subgroup = "fluid-recipes",
    enabled = false,
    always_show_made_in = true,
    allow_as_intermediate = false
  },
  {
    type = "recipe",
    category = "chemistry",
    name = data_util.mod_prefix .. "cryonite-slush",
    results = {
      {type = "fluid", name = data_util.mod_prefix .. "cryonite-slush", amount = 10},
    },
    energy_required = 5,
    ingredients = {
      {name = data_util.mod_prefix .. "cryonite-rod", amount = 1},
      {type = "fluid", name = "sulfuric-acid", amount = 1},
    },
    crafting_machine_tint = RecipeTints.cryonite_tint,
    subgroup = "fluid-recipes",
    enabled = false,
    always_show_made_in = true,
    allow_as_intermediate = false
  },
  {
    type = "recipe",
    category = "chemistry",
    name = data_util.mod_prefix .. "cryonite-to-water-ice",
    results = {
      {name = data_util.mod_prefix .. "water-ice", amount = 1},
    },
    energy_required = 1,
    ingredients = {
      {type = "fluid", name = data_util.mod_prefix .. "cryonite-slush", amount = 1},
      {type = "fluid", name = "water", amount = 100},
    },
    crafting_machine_tint = RecipeTints.cryonite_tint,
    subgroup = "fluid-recipes",
    enabled = false,
    always_show_made_in = true,
    allow_as_intermediate = false
  },
  {
    type = "recipe",
    category = "chemistry",
    name = data_util.mod_prefix .. "steam-to-water",
    results = {
      {type = "fluid", name = "water", amount = 99},
    },
    energy_required = 0.5,
    ingredients = {
      {type = "fluid", name = "steam", amount = 100},
    },
    subgroup = "fluid-recipes",
    enabled = false,
    always_show_made_in = true,
    allow_as_intermediate = false
  },

  {
    type = "recipe",
    category = "pulverising",
    name = data_util.mod_prefix .. "holmium-ore-crushed",
    results = {
      {name = data_util.mod_prefix .. "holmium-ore-crushed", amount = 1}
    },
    energy_required = 1,
    ingredients = {
      {name = data_util.mod_prefix .. "holmium-ore", amount = 2}
    },
    enabled = false,
    always_show_made_in = true,
  },
  {
    type = "recipe",
    category = "pressure-washing",
    name = data_util.mod_prefix .. "holmium-ore-washed",
    main_product = data_util.mod_prefix .. "holmium-ore-washed",
    results = {
      {name = data_util.mod_prefix .. "holmium-ore-washed", amount = 2},
      {name = "stone", amount_min = 1, amount_max = 1, probability = 0.25},
    },
    energy_required = 1,
    ingredients = {
      {type = "fluid", name="water", amount = 2, catalyst_amount = 2},
      {name = data_util.mod_prefix .. "holmium-ore-crushed", amount = 2}
    },
    enabled = false,
    always_show_made_in = true,
    crafting_machine_tint = RecipeTints.holmium_tint,
  },
  {
    type = "recipe",
    category = "chemistry",
    name = data_util.mod_prefix .. "holmium-powder",
    main_product = data_util.mod_prefix .. "holmium-powder",
    results = {
      {name = data_util.mod_prefix .. "holmium-powder", probability = 0.5, amount_min = 1, amount_max = 1},
      {name = data_util.mod_prefix .. "vulcanite-ion-exchange-beads", probability = 0.5, amount_min = 1, amount_max = 1, catalyst_amount = 1},
      {name = data_util.mod_prefix .. "holmium-ore-washed", probability = 0.5, amount_min = 1, amount_max = 1, catalyst_amount = 1},
      {name = "sand", probability = 0.25, amount_min = 1, amount_max = 1, catalyst_amount = 1},
    },
    energy_required = 1,
    ingredients = {
      {type = "fluid", name="water", amount = 2, catalyst_amount = 2},
      {name = data_util.mod_prefix .. "vulcanite-ion-exchange-beads", amount = 1, catalyst_amount = 1,},
      {name = data_util.mod_prefix .. "holmium-ore-washed", amount = 1, catalyst_amount = 1,}
    },
    enabled = false,
    always_show_made_in = true,
    crafting_machine_tint = RecipeTints.holmium_tint,
  },
  {
    type = "recipe",
    category = "smelting",
    name = data_util.mod_prefix .. "holmium-ingot",
    results = {
      {name = data_util.mod_prefix .. "holmium-ingot", amount = 1},
    },
    energy_required = 40,
    ingredients = {
      {name = data_util.mod_prefix .. "holmium-powder", amount = 10},
    },
    enabled = false,
    always_show_made_in = true,
  },
  {
    type = "recipe",
    category = "crafting",
    name = data_util.mod_prefix .. "holmium-plate",
    results = {
      {name = data_util.mod_prefix .. "holmium-plate", amount = 4},
    },
    energy_required = 8,
    ingredients = {
      {name = data_util.mod_prefix .. "holmium-ingot", amount = 1}
    },
    enabled = false,
    always_show_made_in = true,
  },

  {
    type = "recipe",
    category = "pulverising",
    name = data_util.mod_prefix .. "iridium-ore-crushed", -- 2
    results = {
      {name = data_util.mod_prefix .. "iridium-ore-crushed", amount = 1}
    },
    energy_required = 1,
    ingredients = {
      {name = data_util.mod_prefix .. "iridium-ore", amount = 2}
    },
    enabled = false,
    always_show_made_in = true,
  },
  {
    type = "recipe",
    category = "pressure-washing",
    name = data_util.mod_prefix .. "iridium-ore-washed", -- 2
    main_product = data_util.mod_prefix .. "iridium-ore-washed",
    results = {
      {name = data_util.mod_prefix .. "iridium-ore-washed", amount = 2},
      {name = "stone", amount_min = 1, amount_max = 1, probability = 0.25},
    },
    energy_required = 1,
    ingredients = {
      {type = "fluid", name="water", amount = 2, catalyst_amount = 2},
      {name = data_util.mod_prefix .. "iridium-ore-crushed", amount = 2}
    },
    enabled = false,
    always_show_made_in = true,
    crafting_machine_tint = RecipeTints.iridium_tint,
  },
  {
    type = "recipe",
    category = "chemistry",
    name = data_util.mod_prefix .. "iridium-powder", -- 4
    main_product = data_util.mod_prefix .. "iridium-powder",
    results = {
      {name = data_util.mod_prefix .. "iridium-powder", probability = 0.5, amount_min = 1, amount_max = 1},
      {name = data_util.mod_prefix .. "cryonite-ion-exchange-beads", probability = 0.5, amount_min = 1, amount_max = 1, catalyst_amount = 1},
      {name = data_util.mod_prefix .. "iridium-ore-washed", probability = 0.5, amount_min = 1, amount_max = 1, catalyst_amount = 1},
      {name = "sand", probability = 0.25, amount_min = 1, amount_max = 1, catalyst_amount = 1},
    },
    energy_required = 1,
    ingredients = {
      {type = "fluid", name="water", amount = 2, catalyst_amount = 2},
      {name = data_util.mod_prefix .. "cryonite-ion-exchange-beads", amount = 1, catalyst_amount = 1,},
      {name = data_util.mod_prefix .. "iridium-ore-washed", amount = 1, catalyst_amount = 1,}
    },
    enabled = false,
    always_show_made_in = true,
    crafting_machine_tint = RecipeTints.iridium_tint,
  },
  {
    type = "recipe",
    category = "smelting",
    name = data_util.mod_prefix .. "iridium-ingot", -- 40
    results = {
      {name = data_util.mod_prefix .. "iridium-ingot", amount = 1},
    },
    energy_required = 40,
    ingredients = {
      {name = data_util.mod_prefix .. "iridium-powder", amount = 10},
        {name=data_util.mod_prefix .. "vulcanite-block", amount = 1},
    },
    enabled = false,
    always_show_made_in = true,
  },
  {
    type = "recipe",
    category = "crafting",
    name = data_util.mod_prefix .. "iridium-plate", -- 10
    results = {
      {name = data_util.mod_prefix .. "iridium-plate", amount = 4},
    },
    energy_required = 8,
    ingredients = {
      {name = data_util.mod_prefix .. "iridium-ingot", amount = 1}
    },
    enabled = false,
    always_show_made_in = true,
  },
  {
    type = "recipe",
    category = "pulverising",
    name = data_util.mod_prefix .. "naquium-ore-crushed",
    results = {
      {name = data_util.mod_prefix .. "naquium-ore-crushed", amount = 1}
    },
    energy_required = 2,
    ingredients = {
      {name = data_util.mod_prefix .. "naquium-ore", amount = 4}
    },
    enabled = false,
    always_show_made_in = true,
  },
  {
    type = "recipe",
    category = "pressure-washing",
    name = data_util.mod_prefix .. "naquium-ore-washed",
    main_product = data_util.mod_prefix .. "naquium-ore-washed",
    results = {
      {name = data_util.mod_prefix .. "naquium-ore-washed", amount = 2},
      {name = "stone", amount_min = 1, amount_max = 1, probability = 0.25},
    },
    energy_required = 2,
    ingredients = {
      {type = "fluid", name="water", amount = 4},
      {name = data_util.mod_prefix .. "naquium-ore-crushed", amount = 2}
    },
    enabled = false,
    always_show_made_in = true,
    crafting_machine_tint = RecipeTints.naq_tint,
  },
  {
    type = "recipe",
    category = "pressure-washing",
    name = data_util.mod_prefix .. "naquium-powder",
    main_product = data_util.mod_prefix .. "naquium-powder",
    results = {
      {name = data_util.mod_prefix .. "naquium-powder", amount = 1},
      {name = "sand", probability = 0.5, amount_min = 1, amount_max = 1,},
      {type="fluid", name = "water", amount = 2},
    },
    energy_required = 20,
    ingredients = {
      {name=data_util.mod_prefix .. "vitalic-acid", amount = 4},
      {name = data_util.mod_prefix .. "naquium-ore-washed", amount = 2}
    },
    enabled = false,
    always_show_made_in = true,
    crafting_machine_tint = RecipeTints.naq_tint,
  },
  {
    type = "recipe",
    category = "smelting",
    name = data_util.mod_prefix .. "naquium-ingot",
    results = {
      {name = data_util.mod_prefix .. "naquium-ingot", amount = 1},
    },
    energy_required = 60,
    ingredients = {
      {name = data_util.mod_prefix .. "naquium-powder", amount = 10},
        {name=data_util.mod_prefix .. "vulcanite-block", amount = 1},
    },
    enabled = false,
    always_show_made_in = true,
  },
  {
    type = "recipe",
    category = "crafting",
    name = data_util.mod_prefix .. "naquium-plate",
    results = {
      {name = data_util.mod_prefix .. "naquium-plate", amount = 4},
    },
    energy_required = 10,
    ingredients = {
      {name = data_util.mod_prefix .. "naquium-ingot", amount = 1}
    },
    enabled = false,
    always_show_made_in = true,
  },

  {
    type = "recipe",
    category = "pulverising",
    name = data_util.mod_prefix .. "vitamelange-nugget",
    results = {
      {name = data_util.mod_prefix .. "vitamelange-nugget", amount = 2}, -- 0.5
    },
    energy_required = 1,
    ingredients = {
      {name = data_util.mod_prefix .. "vitamelange", amount = 1}
    },
    enabled = false,
    always_show_made_in = true,
  },
  {
    type = "recipe",
    category = "smelting",
    name = data_util.mod_prefix .. "vitamelange-roast",
    results = {
      {name = data_util.mod_prefix .. "vitamelange-roast", amount = 50} -- 1
    },
    energy_required = 100,
    ingredients = {
      {name=data_util.mod_prefix .. "vulcanite-block", amount = 1},
      {name = data_util.mod_prefix .. "vitamelange-nugget", amount = 100}
    },
    enabled = false,
    always_show_made_in = true,
  },
  {
    type = "recipe",
    category = "crafting",
    name = data_util.mod_prefix .. "vitamelange-spice", -- 2
    results = {
      {name = data_util.mod_prefix .. "vitamelange-spice", amount_min=1, amount_max=1, probability=0.5},
    },
    energy_required = 1,
    ingredients = {
      {name = data_util.mod_prefix .. "vitamelange-roast", amount = 1}
    },
    enabled = false,
    always_show_made_in = true,
  },
  {
    type = "recipe",
    category = "chemistry",
    name = data_util.mod_prefix .. "vitamelange-extract", -- 4
    results = {
      {name = data_util.mod_prefix .. "vitamelange-extract", amount_min=1, amount_max=1, probability=0.5},
    },
    energy_required = 1,
    ingredients = {
      {name = data_util.mod_prefix .. "vitamelange-spice", amount = 1}
    },
    crafting_machine_tint = RecipeTints.vita_tint,
    enabled = false,
    always_show_made_in = true,
  },


  {
    type = "recipe",
    category = "pulverising",
    name = data_util.mod_prefix .. "vulcanite-crushed",
    results = {
      {name = data_util.mod_prefix .. "vulcanite-crushed", amount = 1}
    },
    energy_required = 0.5,
    ingredients = {
      {name = data_util.mod_prefix .. "vulcanite", amount = 2}
    },
    enabled = false,
    always_show_made_in = true,
  },
  {
    type = "recipe",
    category = "pressure-washing",
    name = data_util.mod_prefix .. "vulcanite-washed",
    main_product = data_util.mod_prefix .. "vulcanite-washed",
    results = {
      {name = data_util.mod_prefix .. "vulcanite-washed", amount = 2},
      {name = "stone", amount_min = 1, amount_max = 1, probability = 0.25},
      {type = "fluid", name="steam", amount = 2, temperature = 165},
    },
    energy_required = 1,
    ingredients = {
      {type = "fluid", name="water", amount = 4},
      {name = data_util.mod_prefix .. "vulcanite-crushed", amount = 2}
    },
    enabled = false,
    always_show_made_in = true,
    crafting_machine_tint = RecipeTints.vulcanite_tint,
  },
  {
    type = "recipe",
    category = "crafting",
    name = data_util.mod_prefix .. "vulcanite-block",
    results = {
      {name = data_util.mod_prefix .. "vulcanite-block", amount = 1},
    },
    energy_required = 1,
    ingredients = {
      {name = data_util.mod_prefix .. "vulcanite-washed", amount = 1}
    },
    enabled = false,
    always_show_made_in = true,
  },
  {
    type = "recipe",
    category = "chemistry",
    name = data_util.mod_prefix .. "vulcanite-ion-exchange-beads",
    results = {
      {name = data_util.mod_prefix .. "vulcanite-ion-exchange-beads", amount = 10},
    },
    energy_required = 10,
    ingredients = {
      {name = data_util.mod_prefix .. "vulcanite-block", amount = 1},
      {name = "plastic-bar", amount = 1},
      {type = "fluid", name = "sulfuric-acid", amount = 5},
      {type = "fluid", name = "steam", amount = 5},
    },
    crafting_machine_tint = RecipeTints.vulcanite_tint,
    enabled = false,
    always_show_made_in = true,
  },


})
