local collision_mask_util_extended = require("__combat-mechanics-overhaul__/collision-mask-util-extended/data/collision-mask-util-extended")

local flying_layer = collision_mask_util_extended.get_make_named_collision_mask("flying-layer")

local projectile_layer = collision_mask_util_extended.get_make_named_collision_mask("projectile-layer")

local vehicle_layer = collision_mask_util_extended.get_make_named_collision_mask("vehicle-layer")
