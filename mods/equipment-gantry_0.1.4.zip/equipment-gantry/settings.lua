data:extend{
    {
        type = "bool-setting",
        name = "print-equipment-gantry-warnings",
        setting_type = "runtime-per-user",
        default_value = false,
        order = "a"
    },
}
