local Informatron = {} -- informatron pages implementation.

function Informatron.menu(player_index)
  local player = game.players[player_index]
  local menu = {
    --equipment-gantry = 1, -- already exists due to mod name
  }
  return menu
end

function Informatron.page_content(page_name, player_index, element)
  local player = game.players[player_index]
  if page_name == "equipment-gantry" then
    local image_container = element.add{type="frame", name="image_1", style="informatron_image_container", direction="vertical"}
    image_container.style.horizontally_stretchable = true
    image_container.style.horizontal_align = "center"
    image_container.add{type="button", name="image_1", style="informatron_equipment-gantry"} -- image is the background
    element.add{type="label", name="text_1", caption={"equipment-gantry.page_equipment-gantry_text_1"}}
  end
end

return Informatron
