if not logged_mods_once then logged_mods_once = true log("Log mods once: "..serpent.block(mods)) end

require("prototypes/combined/equipment-gantry")
