local version = 000312 -- 0.3.12

Util = require("scripts/util")
local util = Util
Event = require("scripts/event")

Informatron = require('scripts/informatron')
EquipmentGantry = require("scripts/equipment-gantry")


remote.add_interface(
  "equipment-gantry",
  {
-- informatron implementation
    informatron_menu = function(data)
      return Informatron.menu(data.player_index)
    end,

    informatron_page_content = function(data)
      return Informatron.page_content(data.page_name, data.player_index, data.element)
    end,
  }
)
