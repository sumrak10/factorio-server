local diagnostics = require("diagnostics")

local diagnostics_message = diagnostics.get_message(mods)
log(diagnostics_message)
