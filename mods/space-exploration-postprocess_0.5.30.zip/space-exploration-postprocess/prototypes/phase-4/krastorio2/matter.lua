local data_util = require("data_util")

-- This source is dedicated to integrating SE and K2's competing Matter and Antimater mechanics.
-- Progression philosophy is:
-- - SE Energy Science Pack 3
-- - SE Matter Fabricator
-- - SE Energy Science Pack 4
-- - K2 Matter Tech Card
-- - SE Matter Fusion
-- - SE Deep Space Science Pack 1
-- - SE Antimatter Production
-- - SE Deep Space Science Pack 2
-- - K2 Matter Processing
-- - K2 Singularity Tech Card
-- - K2 Antimatter Reactor (Renamed to Singularity Reactor)

-- -- Matter
-- Adjust Cost of Matter Tech Card?

-- Material Fabricator Tech costs cheaper science packs than its required techs, update cost of tech to include the required science packs
-- NB: Should be done in base SE mod.
data_util.tech_remove_prerequisites("se-space-material-fabricator",{"se-energy-science-pack-4"})
data_util.tech_remove_ingredients("se-space-material-fabricator",{"se-energy-science-pack-1","se-material-science-pack-1"})
data_util.tech_add_prerequisites("se-space-material-fabricator",{"se-energy-science-pack-3"})
data_util.tech_add_ingredients("se-space-material-fabricator",{"se-energy-science-pack-3","se-material-science-pack-2"})

-- Bring the Matter Tech Card to after the Matter Fabricator Tech
data_util.tech_remove_prerequisites("kr-matter-tech-card",{"se-naquium-tessaract","kr-singularity-lab","se-deep-space-science-pack-2"})
data_util.tech_remove_ingredients("kr-matter-tech-card",{"se-deep-space-science-pack-2"})
data_util.tech_add_prerequisites("kr-matter-tech-card",{"kr-quantum-computer","se-space-material-fabricator"})
data_util.tech_add_ingredients("kr-matter-tech-card",{"se-energy-science-pack-4","se-material-science-pack-2","se-astronomic-science-pack-2"})

-- Add Matter Tech Card to Techs decending from Matter Fabricator Tech
data_util.tech_add_prerequisites("se-nanomaterial",{"kr-matter-tech-card"})
data_util.tech_add_ingredients("se-nanomaterial",{"matter-tech-card"})

data_util.tech_remove_ingredients("se-space-matter-fusion",{"automation-science-pack","logistic-science-pack","chemical-science-pack"})
data_util.tech_add_prerequisites("se-space-matter-fusion",{"kr-matter-tech-card"})
data_util.tech_add_ingredients("se-space-matter-fusion",{"production-science-pack","utility-science-pack","matter-tech-card"})

-- Update Matter Processing Tech to require Naquium Tesseract Tech
data_util.tech_add_prerequisites("kr-matter-processing",{"se-naquium-tessaract"})

-- Add Naquium products to K2 Matter processes
--(Moved from krastorio2.lua) requires a future Balance pass?
data_util.replace_or_add_ingredient("matter-stabilizer", nil, "se-naquium-cube", 1)
data_util.replace_or_add_ingredient("matter-stabilizer", nil, "se-naquium-tessaract", 1)

data_util.replace_or_add_ingredient("kr-matter-plant", nil, "se-naquium-tessaract", 1)
data_util.replace_or_add_ingredient("kr-matter-assembler", nil, "se-naquium-tessaract", 1)

-- SE Antimatter
-- Update SE Antimatter Production Tech to require Matter Fusion Tech
data_util.tech_add_prerequisites("se-antimatter-production",{"se-space-matter-fusion"})
data_util.tech_add_ingredients("se-antimatter-production",{"matter-tech-card"})

-- Add Matter Tech Card to Techs decending from SE Antimatter Production Tech
data_util.tech_add_ingredients("se-antimatter-reactor",{"matter-tech-card"})
data_util.tech_add_ingredients("se-antimatter-engine",{"matter-tech-card"})
data_util.tech_add_ingredients("se-spaceship-victory",{"matter-tech-card"})

-- Move K2 Antimatter Weaponry to SE Antimatter Reactor
data_util.tech_remove_prerequisites("kr-antimatter-ammo",{"kr-antimatter-reactor"})
data_util.tech_remove_ingredients("kr-antimatter-ammo",{"singularity-tech-card"})
data_util.tech_add_prerequisites("kr-antimatter-ammo",{"se-antimatter-reactor"})

-- K2 Antimatter (Renamed to Singularity)
-- Add Naquium products to K2 Antimatter processes
data_util.replace_or_add_ingredient("kr-antimatter-reactor", nil, "se-naquium-processor", 10)
data_util.replace_or_add_ingredient("kr-antimatter-reactor", nil, "se-naquium-plate", 350)
data_util.replace_or_add_ingredient("kr-antimatter-reactor", "steel-plate", "se-antimatter-reactor", 1)

data_util.replace_or_add_ingredient("antimatter-reactor-equipment", nil, "se-naquium-processor", 1)

-- Add Matter Tech Card to Naquium processing
data_util.tech_add_prerequisites("se-processing-naquium",{"kr-matter-tech-card"})
data_util.tech_add_ingredients("se-processing-naquium",{"matter-tech-card"})

-- Add Matter Tech Card to Nanomaterial requiring techs
data_util.tech_add_ingredients("se-adaptive-armour-5",{"matter-tech-card"})
data_util.tech_add_ingredients("se-big-heat-exchanger",{"matter-tech-card"})
data_util.tech_add_ingredients("se-big-turbine",{"matter-tech-card"})

-- Add Matter Tech Card to Naquium Cube requiring techs
data_util.tech_add_ingredients("se-naquium-cube",{"matter-tech-card"})
data_util.tech_add_ingredients("se-space-solar-panel-3",{"matter-tech-card"})
data_util.tech_add_ingredients("se-space-accumulator-2",{"matter-tech-card"})

-- Add Matter Tech Card to Naquium Tesseract requiring techs
data_util.tech_add_ingredients("se-naquium-tessaract",{"matter-tech-card"})
data_util.tech_add_ingredients("se-lifesupport-equipment-4",{"matter-tech-card"})

-- Add Matter Tech Card to Naquium Processor requiring techs
data_util.tech_add_ingredients("se-naquium-processor",{"matter-tech-card"})
data_util.tech_add_ingredients("se-thruster-suit-4",{"matter-tech-card"})
data_util.tech_add_ingredients("se-nexus",{"matter-tech-card"})

-- Add Matter Tech Card to Factory Spaceship
data_util.tech_add_ingredients("se-spaceship-integrity-7",{"matter-tech-card"})
data_util.tech_add_ingredients("se-factory-spaceship-1",{"matter-tech-card"})
data_util.tech_add_ingredients("se-factory-spaceship-2",{"matter-tech-card"})
data_util.tech_add_ingredients("se-factory-spaceship-3",{"matter-tech-card"})
data_util.tech_add_ingredients("se-factory-spaceship-4",{"matter-tech-card"})
data_util.tech_add_ingredients("se-factory-spaceship-5",{"matter-tech-card"})



-- reduce effectivness of matter deconversion
-- otherwise it is too easy to bypass planet resource restrictions.
for _, recipe in pairs(data.raw.recipe) do
  if recipe.subgroup == "matter-deconversion" then
    for _, ingredient in pairs(recipe.ingredients) do
      if ingredient.name == "matter" then
        ingredient.amount = ingredient.amount * 2
        if ingredient.catalyst_amount then
          ingredient.catalyst_amount = ingredient.catalyst_amount * 2
        end
      end
    end
  end
end
