local data_util = require("data_util")

-- This source is dedicated to integrating K2 and SEs materials into each others intermediaries

-- Integrate Silicon into the Data Card recipe
data_util.replace_or_add_ingredient("se-data-storage-substrate", nil, "silicon", 2)

-- Create a recipe for Data Cards using Rare Metals
local adv_data_recipe = table.deepcopy(data.raw.recipe["se-data-storage-substrate"])
adv_data_recipe.name = "se-kr-rare-metal-substrate"
adv_data_recipe.energy_required = 10
adv_data_recipe.ingredients = {
  {"glass",2},
  {"iron-plate",2},
  {"silicon",2},
  {"rare-metals",2}
}
adv_data_recipe.results = {
  { "se-data-storage-substrate", 2},
  { name = "se-scrap", amount_min = 1, amount_max = 2, probability = 0.5 },
}
adv_data_recipe.icon = nil
adv_data_recipe.icons = data_util.add_icons_to_stack(
  nil, {
    {icon = data.raw.item["se-data-storage-substrate"], properties = {scale = 1, offset = {0,0}}},
    {icon = data.raw.item["rare-metals"], properties = {scale = 0.75, offset = {0.2,0.2}}}
  }
)
data:extend({adv_data_recipe})
data_util.allow_productivity("se-kr-rare-metal-substrate")

-- Add the recipe to the new K2 tech, if it exists.
if data.raw.technology["kr-efficient-fabrication"] then
  table.insert(
    data.raw.technology["kr-efficient-fabrication"].effects,
    {type = "unlock-recipe", recipe = "se-kr-rare-metal-substrate"}
  )
-- Otherwise unlock it with the Heavy Girder as a fallback
else
  table.insert(
    data.raw.technology["se-heavy-girder"].effects,
    {type = "unlock-recipe", recipe = "se-kr-rare-metal-substrate"}
  )
end

-- AI Core
data_util.tech_remove_prerequisites("kr-ai-core", {"kr-quarry-minerals-extraction","utility-science-pack"})
data_util.tech_add_prerequisites("kr-ai-core",{"se-quantum-processor","se-biological-science-pack-3"})
data_util.tech_add_ingredients("kr-ai-core",{"se-energy-science-pack-3","se-biological-science-pack-3"})
table.insert(data.raw.recipe["ai-core"].ingredients, {type = "fluid", name = "se-neural-gel-2", amount = 20})
data_util.replace_or_add_ingredient("ai-core", "processing-unit", "se-quantum-processor", 2)
data_util.replace_or_add_ingredient("ai-core", "nitric-acid", "se-vitalic-reagent",4)
data_util.replace_or_add_ingredient("ai-core", nil, "se-bioelectrics-data", 2)

-- Integrate the K2 AI Core into the Naquium Processor recipe
data_util.replace_or_add_ingredient("se-naquium-processor","se-quantum-processor","ai-core",1)
data_util.replace_or_add_ingredient("se-naquium-processor-alt","se-quantum-processor","ai-core",1)

-- Nitric Acid has the nitrogen for Anion resin
data_util.replace_or_add_ingredient("se-cryonite-ion-exchange-beads","sulfuric-acid","nitric-acid",5,true)

-- Improved Pollution Filter
data_util.tech_remove_prerequisites("kr-improved-pollution-filter",{"kr-matter-tech-card"})
data_util.tech_remove_ingredients("kr-improved-pollution-filter",{"matter-tech-card","se-deep-space-science-pack-2"})
data_util.tech_add_prerequisites("kr-improved-pollution-filter",{"kr-advanced-tech-card"})
data_util.tech_add_ingredients("kr-improved-pollution-filter",{"advanced-tech-card","se-energy-science-pack-3","se-material-science-pack-2"})

data_util.replace_or_add_ingredient("improved-pollution-filter",nil,"se-cryonite-ion-exchange-beads",1)
data_util.replace_or_add_ingredient("improved-pollution-filter",nil,"se-vulcanite-ion-exchange-beads",1)

---- Beryllium
-- Adjust Aeroframe Scaffold to use Imersium Plate
data_util.replace_or_add_ingredient("se-aeroframe-scaffold", nil, "imersium-plate", 1)

-- Adjust Aeroframe Bulkhead to use Imersium Plate
data_util.replace_or_add_ingredient("se-aeroframe-bulkhead", "se-beryllium-plate", "se-beryllium-plate", 2)
data_util.replace_or_add_ingredient("se-aeroframe-bulkhead", nil, "imersium-plate", 2)

---- Iridium
-- Adjust Heavy Composite item to require Rare Metals
data_util.replace_or_add_ingredient("se-heavy-composite",nil,"rare-metals",4)

-- Adjust Heavy Assembly item to require Imersium Beams
data_util.replace_or_add_ingredient("se-heavy-assembly",nil,"imersium-beam",2)

---- Holmium
-- Replace Holmium plate with Rare metals in Holmium solenoid recipe
data_util.replace_or_add_ingredient("se-holmium-solenoid", "se-holmium-plate", "rare-metals", 2)

-- Adjust Quantum processor to use Imersite crystal
data_util.replace_or_add_ingredient("se-quantum-processor", nil, "imersite-crystal", 2)

-- Adjust Dynamic Emitter item to require Imersite Crystals
data_util.replace_or_add_ingredient("se-dynamic-emitter",nil,"imersite-crystal",2)

---- Vitamelange
-- Replace Sulfuric acid with Nitric acid in Vitalic acid recipe
data_util.replace_or_add_ingredient("se-vitalic-acid", "sulfuric-acid", "nitric-acid", 2, true)

-- Adjust Vitalic reagent to use Lithium chloride
data_util.replace_or_add_ingredient("se-vitalic-reagent", nil, "lithium-chloride", 10)

---- Streams
-- Replace Battery with Lithium-Sulfur Battery in the Magnetic Canister recipe
data_util.replace_or_add_ingredient("se-magnetic-canister","battery","lithium-sulfur-battery",1)
data_util.replace_or_add_ingredient("se-magnetic-canister",nil,"rare-metals",1)

-- Replace Copper in Ion Stream recipe with Rare Metals
data_util.replace_or_add_ingredient("se-ion-stream","copper-plate","rare-metals",1)

-- Replace Stone in Plasma Stream recipe with Lithium
data_util.replace_or_add_ingredient("se-plasma-stream","stone","lithium",1)

---- Biological Science
-- Adjust Nutrient gel to use fertilizer
data_util.replace_or_add_ingredient("se-nutrient-gel", nil, "fertilizer", 5)
data_util.replace_or_add_ingredient("se-nutrient-gel-methane", nil, "fertilizer", 5)

-- Adjust Genetic Data item to require Lithium Chloride
data_util.replace_or_add_ingredient("se-genetic-data",nil,"lithium-chloride",5)

---- Energy Science
-- Adjust Magnetic data packs to require Rare Metals
data_util.replace_or_add_ingredient("se-magnetic-monopole-data",nil,"rare-metals",1)
data_util.replace_or_add_ingredient("se-electromagnetic-field-data",nil,"rare-metals",5)

---- Material Science
-- Replace Stone in Material Testing Pack with Rare Metals
data_util.replace_or_add_ingredient("se-material-testing-pack","stone","rare-metals",1)

-- Adjust Material Testing Pack to require Imersite Crystals
data_util.replace_or_add_ingredient("se-material-testing-pack",nil,"imersite-crystal",1)

-- Replace Copper in Experimental Alloys Data with Rare Metals
data_util.replace_or_add_ingredient("se-experimental-alloys-data","copper-plate","rare-metals",1)

-- Include Rare Metal in scrap recycling
if data.raw.recipe["se-scrap-recycling"] then
  table.insert(data.raw.recipe["se-scrap-recycling"].results,
    {name = "raw-rare-metals", amount_min = 1, amount_max = 1, probability = 0.05}
  )
end

-- Adjust Holmium cable Processing Unit recipe to require Rare Metals
data.raw.recipe["se-processing-unit-holmium"].normal = nil
data.raw.recipe["se-processing-unit-holmium"].expensive = nil
data.raw.recipe["se-processing-unit-holmium"].ingredients = {
  {"advanced-circuit", 3},
  {"rare-metals", 2},
  {"se-holmium-cable", 8},
  {type = "fluid", name="sulfuric-acid", amount=4}
}
data.raw.recipe["se-processing-unit-holmium"].result_count = 2

-- Add Imersite Processing as a prerequisite to Energy Control Units
data_util.tech_add_prerequisites("kr-energy-control-unit", {"kr-quarry-minerals-extraction"})