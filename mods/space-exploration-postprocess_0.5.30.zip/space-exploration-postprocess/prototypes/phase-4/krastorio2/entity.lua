local data_util = require("data_util")

-- This source is dedicated to making changes to K2 and SE entities

local function move_to_specialist_science_packs(tech_name, science_packs, require_imersium)
	data_util.tech_remove_ingredients(tech_name, {"space-science-pack", "matter-tech-card", "advanced-tech-card", "se-deep-space-science-pack-1"})
	data_util.tech_remove_prerequisites(tech_name, {"space-science-pack", "kr-matter-tech-card", "kr-advanced-tech-card", "se-deep-space-science-pack-1"})
	data_util.tech_add_ingredients(tech_name, science_packs)
	data_util.tech_add_prerequisites(tech_name, science_packs)
	if require_imersium then
		data_util.tech_add_prerequisites(tech_name, {"kr-imersium-processing"})
	end
end

-- Advanced Assembler
move_to_specialist_science_packs("kr-automation", {"se-material-science-pack-2"})
data_util.tech_add_prerequisites("kr-automation", {"se-heavy-bearing"})
data_util.replace_or_add_ingredient("kr-advanced-assembling-machine", "ai-core", "se-heavy-bearing", 10)
data.raw.recipe["kr-advanced-assembling-machine"].subgroup = "assembling"
data.raw.item["kr-advanced-assembling-machine"].subgroup = "assembling"

-- Advanced Furnace
move_to_specialist_science_packs("kr-advanced-furnace", {"se-material-science-pack-1"}, true)
local adv_furnace = data.raw["assembling-machine"]["kr-advanced-furnace"]
adv_furnace.crafting_speed = 8
adv_furnace.module_specification.module_slots = 5

-- Advanced Chemical Plant
move_to_specialist_science_packs("kr-advanced-chemical-plant", {"se-biological-science-pack-2"})
data.raw.recipe["kr-advanced-chemical-plant"].subgroup = "chemistry"
data.raw.item["kr-advanced-chemical-plant"].subgroup = "chemistry"

-- Update the cost of the Advanced Robotport Tech
data_util.tech_add_ingredients("kr-advanced-roboports",{"se-rocket-science-pack","space-science-pack","se-material-science-pack-3","se-energy-science-pack-3"})

-- Include SE Resources in Advanced Roboport Recipes
data_util.replace_or_add_ingredient("kr-large-roboport","rare-metals","rare-metals",40)
data_util.replace_or_add_ingredient("kr-large-roboport",nil,"se-aeroframe-scaffold",20)
data_util.replace_or_add_ingredient("kr-large-roboport",nil,"se-heavy-composite",20)

data_util.replace_or_add_ingredient("kr-small-roboport","rare-metals","rare-metals",10)
data_util.replace_or_add_ingredient("kr-small-roboport",nil,"se-aeroframe-scaffold",5)
data_util.replace_or_add_ingredient("kr-small-roboport",nil,"se-heavy-composite",5)

---- Supercomputers
-- Integrate the K2 AI Core into Neural Supercomputers recipe
data_util.tech_add_prerequisites("se-space-supercomputer-3",{"kr-ai-core"})
data_util.replace_or_add_ingredient("se-space-supercomputer-3","se-bioelectrics-data","ai-core", 50)
data_util.remove_ingredient_sub(data.raw.recipe["se-space-supercomputer-3"],"se-neural-gel-2")

-- Integrate the K2 AI Core into the Dimensional Anchor recipe
data_util.replace_or_add_ingredient("se-dimensional-anchor","se-quantum-processor","ai-core",8)

-- Add Imersium Beams to the Advanced Research Server recipe
data_util.replace_or_add_ingredient("kr-quantum-computer", "steel-beam", "imersium-beam", 20)

-- Adjust Pylon recipies to use Lithium-Sulfur batteries instead
data_util.replace_or_add_ingredient("se-pylon-substation","battery","lithium-sulfur-battery",16)
data_util.replace_or_add_ingredient("se-pylon-construction","battery","lithium-sulfur-battery",16)
data_util.replace_or_add_ingredient("se-pylon-construction-radar","battery","lithium-sulfur-battery",16)

-- Rebalancing the K2 Fusion Reactor
data_util.tech_add_prerequisites("kr-fusion-energy", {"se-space-particle-collider"})
move_to_specialist_science_packs("kr-fusion-energy", {"se-energy-science-pack-3"})
move_to_specialist_science_packs("fusion-reactor-equipment", {"se-energy-science-pack-3"})

-- 16720 to power 16 K2 Advanced Turbines, for an output of 1.6GW, pretty much the limit of efficiency for D-T Fusion.
data.raw.recipe["kr-fusion"].ingredients = {
	{ type = "fluid", name = "water", amount = 16720},
	{ type = "item", name = "dt-fuel", amount = 1 },
}
data.raw.recipe["kr-fusion"].results = {
	{ type = "fluid", name = "steam", amount = 16720, temperature = 975 },
	{ type = "item", name = "empty-dt-fuel", amount = 1 }
}
data.raw["generator"]["kr-advanced-steam-turbine"].max_power_output = "100MW"
data.raw["generator"]["kr-advanced-steam-turbine"].effectivity = 1
-- 1045/300 to get the correct consumption of 209/s of steam to make 100MW at 975C in the Factorio Engine.
data.raw["generator"]["kr-advanced-steam-turbine"].fluid_usage_per_tick = 1045/300

-- Sheild Projector
-- Include K2 Advanced Tech Card and Lithium Sulfur Battery instead of Base battery.
data_util.tech_add_ingredients("shield-projector",{"advanced-tech-card"})
data_util.replace_or_add_ingredient("shield-projector","battery","lithium-sulfur-battery",160)

-- Add Space Science packs to more K2 technologies
--Integrate Material Science and its products into K2 Belts.
data_util.tech_remove_prerequisites("kr-logistic-4", {"utility-science-pack"})
data_util.tech_add_prerequisites("kr-logistic-4", {"kr-imersium-processing","se-material-science-pack-1"})
data_util.tech_add_ingredients("kr-logistic-4", {"se-material-science-pack-1"})
data_util.replace_or_add_ingredient("kr-advanced-splitter","steel-gear-wheel","imersium-gear-wheel",4)
data_util.replace_or_add_ingredient("kr-advanced-transport-belt","steel-gear-wheel","imersium-gear-wheel",4)

data_util.tech_remove_prerequisites("kr-logistic-5", {"kr-advanced-tech-card"})
data_util.tech_remove_ingredients("kr-logistic-5", {"advanced-tech-card"})
data_util.tech_add_prerequisites("kr-logistic-5", {"space-science-pack","se-material-science-pack-2"})
data_util.tech_add_ingredients("kr-logistic-5", {"space-science-pack","se-material-science-pack-2"})
data_util.replace_or_add_ingredient("kr-superior-splitter",nil,"se-heavy-bearing",4)
data_util.replace_or_add_ingredient("kr-superior-transport-belt",nil,"se-heavy-bearing",4)

-- Adjust techs so that K2 Solar Panel is required for Flat Solar Panel
data_util.tech_add_prerequisites("se-space-solar-panel",{"kr-advanced-solar-panel"})
data_util.replace_or_add_ingredient("se-space-solar-panel","solar-panel","kr-advanced-solar-panel",1)

-- Adjust prototypes so that Flat Solar Panel upgrades from K2 Solar Panel
local se_space_solar_panel = data.raw["solar-panel"]["se-space-solar-panel"]
data.raw["solar-panel"]["kr-advanced-solar-panel"].fast_replaceable_group = se_space_solar_panel.fast_replaceable_group
data.raw["solar-panel"]["kr-advanced-solar-panel"].collision_box = se_space_solar_panel.collision_box
data.raw["solar-panel"]["kr-advanced-solar-panel"].collision_mask = se_space_solar_panel.collision_mask
data.raw["solar-panel"]["kr-advanced-solar-panel"].next_upgrade = "se-space-solar-panel"

-- Reorder K2 Solar Panel to be with other solar panels.
data.raw.recipe["kr-advanced-solar-panel"].subgroup = "solar"
data.raw.recipe["kr-advanced-solar-panel"].order = "d[solar-panel]-a[solar-panel]-a"

data.raw.item["kr-advanced-solar-panel"].subgroup = "solar"
data.raw.item["kr-advanced-solar-panel"].order = "d[solar-panel]-a[solar-panel]-a"

-- Move K2 Energy Storage Tech to after Naquium Accumulator
data_util.tech_remove_prerequisites("kr-energy-storage",{"electric-energy-accumulators","kr-energy-control-unit","kr-matter-tech-card"})
data_util.tech_add_prerequisites("kr-energy-storage",{"se-space-accumulator-2","se-naquium-processor"})
data_util.tech_add_ingredients("kr-energy-storage",{"se-astronomic-science-pack-4","se-energy-science-pack-4","se-material-science-pack-4","se-deep-space-science-pack-3"})

-- Improve Energy Storage entity to account for now being the final accumulator
if data.raw.accumulator["kr-energy-storage"] then
	local accu = data.raw.accumulator["kr-energy-storage"]
	-- Pretty sure this might be OP, but hey, we're at DSS3 here.
	accu.energy_source = {
		type = "electric",
		buffer_capacity = "5000MJ",
		usage_priority = "tertiary",
		input_flow_limit = "10MW",
		output_flow_limit = "50MW"
	}
end

-- Increase cost Energy Storage recipe to account for now being the final accumulator
data.raw.recipe["kr-energy-storage"].ingredients = {
	{"se-naquium-plate", 20},
	{"se-naquium-heat-pipe", 10},
	{"se-naquium-processor", 4},
	{"se-space-accumulator-2", 10}
}

data.raw.recipe["kr-energy-storage"].subgroup = "solar"
data.raw.recipe["kr-energy-storage"].order = "e[accumulator]-a[accumulator]-final"
data.raw.recipe["kr-energy-storage"].category = "space-manufacturing"

data.raw.item["kr-energy-storage"].subgroup = "solar"
data.raw.item["kr-energy-storage"].order = "e[accumulator]-a[accumulator]-final"

-- If K2 Advanced Lab exists, add it to the Space Science Laboratory recipe
if data.raw.item["biusart-lab"] then
	data_util.replace_or_add_ingredient("se-space-science-lab", "lab", "biusart-lab", 10)
	data_util.tech_add_prerequisites("se-space-science-lab", {"kr-advanced-lab"})
end

-- Replace Battery with Lithium-Sulfur Battery in the Space Science Laboratory recipe
data_util.replace_or_add_ingredient("se-space-science-lab","battery","lithium-sulfur-battery",10)

-- Advanced Beacon    = 0.75 * 15 modules = 10.5 module equivalant over 6*6 area
-- Wide Area Beacon   = 0.5  * 15 modules =  7.5 module equivalant over 32*32 area
-- Wide Area Beacon 2 = 0.5  * 20 modules = 10.0 module equivalant over 32*32 area
if data.raw.beacon["kr-singularity-beacon"] then
	-- Advanced Beacon
	local beacon = data.raw.beacon["kr-singularity-beacon"]
	beacon.energy_usage = "400kW"
	beacon.supply_area_distance = 2 -- The limiting factor is the very short range.
	beacon.distribution_effectivity = 0.75
	--beacon.distribution_effectivity = 0.666666666667
	beacon.module_specification = {
		module_info_icon_shift = {0, 0.5},
		module_info_max_icons_per_row = 5,
		module_info_max_icon_rows = 3,
		module_info_multi_row_initial_height_modifier = -0.5,
		module_slots = 15,
		module_info_icon_scale = 0.3
	} -- 0.75 * 15 slots = 10.5. Max for wide are beacons is 10.
	-- Means these are the most powerful beacons, and they are available earliest after normal beacons.
	data_util.tech_remove_ingredients("kr-singularity-beacon", {"space-science-pack", "matter-tech-card", "advanced-tech-card", "singularity-tech-card", "se-deep-space-science-pack-1"})
	data_util.tech_add_ingredients("kr-singularity-beacon", {"se-energy-science-pack-1"})
	data.raw.technology["kr-singularity-beacon"].prerequisites = {"effect-transmission", "se-holmium-cable", "kr-energy-control-unit"}
	data_util.replace_or_add_ingredient("kr-singularity-beacon", "ai-core", "se-holmium-cable", 40)
	data_util.replace_or_add_ingredient("kr-singularity-beacon", nil, data_util.mod_prefix .. "energy-catalogue-1", 1)

	data.raw.technology["se-wide-beacon"].prerequisites = {"effect-transmission", "kr-energy-control-unit", "se-superconductive-cable", "kr-imersium-processing"}
	data_util.tech_remove_ingredients("se-wide-beacon", {"se-energy-science-pack-1"})
	data_util.tech_add_ingredients("se-wide-beacon", {"se-energy-science-pack-3"})
	data_util.replace_or_add_ingredient("se-wide-beacon", "se-holmium-cable", "se-superconductive-cable", 40)
  data_util.replace_or_add_ingredient("se-wide-beacon", "processing-unit", "processing-unit", 40)
  data_util.replace_or_add_ingredient("se-wide-beacon", "low-density-structure", "low-density-structure", 40)
  data_util.replace_or_add_ingredient("se-wide-beacon", nil, "imersium-plate", 20)
  data_util.replace_or_add_ingredient("se-wide-beacon", nil, "energy-control-unit", 20)

	data.raw.technology["se-wide-beacon-2"].prerequisites = {"se-wide-beacon", "se-dynamic-emitter", "se-naquium-processor", "kr-singularity-tech-card"}
	data_util.tech_add_ingredients("se-wide-beacon-2", {"singularity-tech-card"})
	data_util.replace_or_add_ingredient("se-wide-beacon-2", "se-superconductive-cable", "ai-core", 10)

end

-- Adjust Holmium Accumulator item to require Lithium-Sulfur Batteries
data_util.tech_add_prerequisites("se-space-accumulator",{"kr-energy-control-unit"})
data_util.replace_or_add_ingredient("se-space-accumulator",nil,"energy-control-unit",2)

-- Integrate the Miners.
data_util.tech_add_prerequisites("area-mining-drill", {"kr-electric-mining-drill-mk2"})
data_util.replace_or_add_ingredient("area-mining-drill", "electric-mining-drill", "kr-electric-mining-drill-mk2", 1)
data.raw.recipe["area-mining-drill"].order = "a[items]-c[electric-mining-drill-mk2]-b"
data.raw.item["area-mining-drill"].order = "a[items]-c[electric-mining-drill-mk2]-b"

-- Make MK3 miner an upgrade to the Area Miner
data_util.tech_add_prerequisites("kr-electric-mining-drill-mk3", {"kr-advanced-tech-card","area-mining-drill","se-energy-science-pack-4"})
data_util.tech_add_ingredients("kr-electric-mining-drill-mk3", {"advanced-tech-card","se-material-science-pack-3","se-energy-science-pack-4"})
data_util.replace_or_add_ingredient("kr-electric-mining-drill-mk3", "kr-electric-mining-drill-mk2", "area-mining-drill", 1)
data_util.replace_or_add_ingredient("kr-electric-mining-drill-mk3", "ai-core", "se-heavy-bearing", 10)
data_util.replace_or_add_ingredient("kr-electric-mining-drill-mk3", "imersite-crystal", "se-dynamic-emitter", 2)
data_util.replace_or_add_ingredient("kr-electric-mining-drill-mk3", nil, "se-heavy-composite", 4)

local miner_mk3 = data.raw["mining-drill"]["kr-electric-mining-drill-mk3"]
table.insert(miner_mk3.resource_categories, "hard-resource")
miner_mk3.module_specification.module_slots = 5
miner_mk3.energy_usage = "500kW"
miner_mk3.mining_speed = 1.2

move_to_specialist_science_packs("kr-laser-artillery-turret", {"se-energy-science-pack-2"}, true)
data_util.tech_add_prerequisites("kr-laser-artillery-turret", {"se-holmium-solenoid", "se-heavy-girder"})
data_util.replace_or_add_ingredient("kr-laser-artillery-turret", "ai-core", "se-holmium-solenoid", 20)
data_util.replace_or_add_ingredient("kr-laser-artillery-turret", "steel-beam", "se-heavy-girder", 10)

move_to_specialist_science_packs("kr-rocket-turret", {"se-material-science-pack-1"})
data_util.replace_or_add_ingredient("kr-rocket-turret", "steel-beam", "se-heavy-girder", 10)

