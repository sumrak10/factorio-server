local data_util = require("data_util")

if mods["Krastorio2"] then

  ---- Changing science packs icons to Krastorio 2 design for on planet techs
  -- Automation science pack
  krastorio.icons.setItemIcon("automation-science-pack", kr_cards_icons_path .. "automation-tech-card.png")
  data.raw.tool["automation-science-pack"].order = "b02[automation-tech-card]"
  krastorio.icons.setTechnologyIcon("automation-science-pack", kr_technologies_icons_path .. "automation-tech-card.png", 256, 4)

  -- Logistic science pack
  krastorio.icons.setItemIcon("logistic-science-pack", kr_cards_icons_path .. "logistic-tech-card.png")
  data.raw.tool["logistic-science-pack"].order = "b03[logistic-tech-card]"
  krastorio.icons.setTechnologyIcon("logistic-science-pack", kr_technologies_icons_path .. "logistic-tech-card.png", 256, 4)

  -- Military science pack
  krastorio.icons.setItemIcon("military-science-pack", kr_cards_icons_path .. "military-tech-card.png")
  data.raw.tool["military-science-pack"].order = "b04[military-tech-card]"
  krastorio.icons.setTechnologyIcon("military-science-pack", kr_technologies_icons_path .. "military-tech-card.png", 256, 4)

  -- Chemical science pack
  krastorio.icons.setItemIcon("chemical-science-pack", kr_cards_icons_path .. "chemical-tech-card.png")
  data.raw.tool["chemical-science-pack"].order = "b05[chemical-tech-card]"
  krastorio.icons.setTechnologyIcon("chemical-science-pack", kr_technologies_icons_path .. "chemical-tech-card.png", 256, 4)

  -- Production science pack
  krastorio.icons.setItemIcon("production-science-pack", kr_cards_icons_path .. "production-tech-card.png")
  data.raw.tool["production-science-pack"].order = "b06[production-tech-card]"
  krastorio.icons.setTechnologyIcon("production-science-pack",    kr_technologies_icons_path .. "production-tech-card.png", 256, 4)

  -- Utility science pack
  krastorio.icons.setItemIcon("utility-science-pack", kr_cards_icons_path .. "utility-tech-card.png")
  data.raw.tool["utility-science-pack"].order = "b07[utility-tech-card]"
  krastorio.icons.setTechnologyIcon("utility-science-pack", kr_technologies_icons_path .. "utility-tech-card.png", 256, 4)

  -- Space science pack
  krastorio.icons.setItemIcon("space-science-pack", kr_cards_icons_path .. "optimization-tech-card.png")
  data.raw.tool["space-science-pack"].order = "b09[optimization-tech-card]"
  krastorio.icons.setTechnologyIcon("space-science-pack", kr_technologies_icons_path .. "optimization-tech-card.png", 256, 4)
  data.raw.recipe["space-science-pack"].category = "t2-tech-cards"

  -- move some k2 things earlier in the tech tree. Distribute between late rocket science and T4 specialist science.
  -- anything relating to space warping, singularities, matter, or antimatter should be after deep space science
  -- fusion should be around energy science 3.

  -- Move Quarry Mineral Extraction (Imersite Mining) to same stage as other SE space materials
  data_util.tech_add_prerequisites("kr-quarry-minerals-extraction", {"area-mining-drill","se-rocket-science-pack"})
  data_util.tech_add_ingredients("kr-quarry-minerals-extraction", {"se-rocket-science-pack"})

  data_util.tech_remove_prerequisites("kr-imersium-processing", {"kr-matter-tech-card"})
  data_util.tech_remove_ingredients("kr-imersium-processing", {"matter-tech-card"})
  data_util.tech_add_prerequisites("kr-imersium-processing", {"kr-quarry-minerals-extraction"})
  data_util.tech_add_ingredients("kr-imersium-processing", {"se-rocket-science-pack"})

  data_util.tech_remove_ingredients("kr-energy-control-unit", {"matter-tech-card"})
  data_util.tech_remove_prerequisites("kr-energy-control-unit", {"kr-matter-tech-card", "kr-singularity-lab"})
  data_util.tech_add_ingredients("kr-energy-control-unit", {"se-energy-science-pack-1"})
  data_util.tech_add_prerequisites("kr-energy-control-unit", {"se-energy-science-pack-1"})


  local function move_to_specialist_science_packs(tech_name, science_packs, require_imersium)
    data_util.tech_remove_ingredients(tech_name, {"space-science-pack", "matter-tech-card", "advanced-tech-card", "se-deep-space-science-pack-1"})
    data_util.tech_remove_prerequisites(tech_name, {"space-science-pack", "kr-matter-tech-card", "kr-advanced-tech-card", "se-deep-space-science-pack-1"})
    data_util.tech_add_ingredients(tech_name, science_packs)
    data_util.tech_add_prerequisites(tech_name, science_packs)
    if require_imersium then
      data_util.tech_add_prerequisites(tech_name, {"kr-imersium-processing"})
    end
  end

  -- Spidertron
  data_util.tech_remove_prerequisites("spidertron", {"kr-ai-core", "space-science-pack", "kr-matter-tech-card", "kr-advanced-tech-card", "se-deep-space-science-pack"})
  move_to_specialist_science_packs("spidertron", {"se-biological-science-pack-1"})

  -- Rebalance cost of Superiror Robot Battery tech
  data_util.tech_add_ingredients("kr-robot-battery-plus",{"se-rocket-science-pack","space-science-pack","advanced-tech-card","se-energy-science-pack-3"})
  data_util.tech_remove_ingredients("kr-robot-battery-plus",{"matter-tech-card"})

  -- Integrate the K2 AI Core so it is not left around chemical science with nothing to do for half the game.

  -- Replace Battery with Lithium-Sulfur Battery in a secret recipe.
  data_util.replace_or_add_ingredient("se-gate-platform","battery","lithium-sulfur-battery",100)

  -- Bring the Advanced Tech Card to after Space Science 3s
  move_to_specialist_science_packs("kr-advanced-tech-card",{"se-energy-science-pack-3","se-material-science-pack-3","se-biological-science-pack-3","se-astronomic-science-pack-3"})
  data_util.tech_add_prerequisites("kr-advanced-tech-card",{"kr-quantum-computer"})

  -- Adjust Advanced Tech Card cost
  data_util.replace_or_add_ingredient("advanced-tech-card","electric-engine-unit","se-bioscrubber",5)
  data_util.replace_or_add_ingredient("advanced-tech-card",nil,"se-pylon",2)
  data_util.replace_or_add_ingredient("advanced-tech-card",nil,"se-space-platform-plating",1)

  -- Remove Advanced Tech Card tech as Prerequisite for Singularity Tech Card
  data_util.tech_remove_prerequisites("kr-singularity-tech-card",{"kr-advanced-tech-card"})

  -- Add Advanced Tech Card tech as cost for Radar Construction Pylon
  data_util.tech_add_prerequisites("se-pylon-construction-radar",{"kr-advanced-tech-card"})
  data_util.tech_add_ingredients("se-pylon-construction-radar",{"advanced-tech-card"})

  -- Adapt techs that seem to be in the wrong place in the tech tree
  -- Advanced Pickaxe Research
  data_util.tech_remove_ingredients("kr-advanced-pickaxe",{"matter-tech-card"})
  data_util.tech_add_ingredients("kr-advanced-pickaxe",{"space-science-pack"})

  data_util.tech_add_prerequisites("kr-antimatter-reactor", {"se-antimatter-reactor"})

  data_util.tech_remove_prerequisites("se-space-decontamination-facility", {"se-rocket-science-pack"})

  -- Rebalance Coal Liquefaction to avoid creation of matter with Prod 9 modules
  data.raw.recipe["coal-liquefaction"].ingredients = {
    {type = "item", name = "coal", amount = 10},
    {type = "fluid", name = "heavy-oil", amount = 25, catalyst_amount = 25},
    {type = "fluid", name = "steam", amount = 50},
  }
  data.raw.recipe["coal-liquefaction"].results = {
    {type = "fluid", name = "heavy-oil", amount = 85, catalyst_amount = 25},
    {type = "fluid", name = "light-oil", amount = 20},
    {type = "fluid", name = "petroleum-gas", amount = 10},
  }

  -- Rebalance Used Fuel Cell Reprocessing to avoid creation of matter with Prod 9 modules
  data.raw.recipe["nuclear-fuel-reprocessing"].results = {
    {type = "item", name = "uranium-238", amount = 5},
    {type = "item", name = "stone", amount = 3},
    {type = "item", name = "tritium", probability = 0.15, amount = 1},
  }

  -- This is the K2 Optimization Tech Card
  if data.raw.item["space-research-data"] and not data.raw.recipe["space-research-data"] then
    data:extend({
      {
          type = "recipe",
          name = "space-research-data",
          enabled = false,
          energy_required = 1,
          ingredients = {
            { "se-iridium-plate", 2 },
            { "se-holmium-plate", 2 },
            { "se-beryllium-plate", 2 },
            { "se-vitamelange-extract", 2 },
            { "imersium-plate", 2 },
          },
          results = {
            {"space-research-data", 1},
          },
          main_product = "space-research-data",
          requester_paste_multiplier = 1,
          subgroup = "science-pack",
          category = "t2-tech-cards"
      }
    })
    data_util.recipe_require_tech("space-research-data", "space-science-pack")
    if not data_util.table_contains(data.raw.lab["se-space-science-lab"].inputs, "space-science-pack") then
      table.insert(data.raw.lab["se-space-science-lab"].inputs, "space-space-science-pack")
    end
    data_util.tech_remove_prerequisites("space-science-pack", {"kr-singularity-lab"})
    data_util.tech_add_ingredients("space-science-pack", {"se-rocket-science-pack"})
    data_util.tech_add_prerequisites("space-science-pack",
      {"kr-imersium-processing", "se-processing-iridium", "se-processing-holmium", "se-processing-beryllium", "se-processing-vitamelange"}
    )

  end

  if data.raw.tool["basic-tech-card"] then
    data_util.tech_remove_ingredients("se-medpack", {"automation-science-pack"})
    data.raw.technology["se-medpack"].prerequisites = {}
  end

  if mods["k2se-compatibility"] and k2se_compatibility_apply_changes then
    k2se_compatibility_apply_changes()
  end

  -- make the SE fuel refinery into an advanced refinery?

  ----------------------------------------------------------------------------------------------------------------------
  -- Begin rocket fuel energy fixes
  -- don't wrap the following changes in if statements, the entities are needed so if one is missing then there is a compatibility problem

  data.raw.item["rocket-fuel"].fuel_value = "100MJ"
  data.raw.item["rocket-fuel"].stack_size = 10

  -- Can't get hydrogen for free. Use electrolyser
  data_util.delete_recipe("hydrogen")

  -- Increase Oxygen and Nitrogen production amount, increase KW usage proportionally
  -- Atmosphere composition is 70:20 Nitrogen:Oxygen, Nitrogen is easier to collect.
  local oxygen = data.raw.recipe["oxygen"]
  oxygen.energy_required = 10
  oxygen.results = {
    {type = "fluid", name = "oxygen", amount = 300}
  }

  local nitrogen = data.raw.recipe["nitrogen"]
  nitrogen.energy_required = 5
  nitrogen.results = {
    {type = "fluid", name = "nitrogen", amount = 475}
  }

  -- Increase cost of Atmospheric Condensing
  data.raw["assembling-machine"]["kr-atmospheric-condenser"].energy_usage = "400kW" --was 250kW

  -- Hydrogen comes from Electrolysis, Increase cost of the process.
  data.raw["assembling-machine"]["kr-electrolysis-plant"].energy_usage = "2500kW" --was 375kW
  data.raw["assembling-machine"]["kr-electrolysis-plant-spaced"].energy_usage = "2500kW" --was 375kW
  collision_mask_util_extended.remove_layer(data.raw["assembling-machine"]["kr-electrolysis-plant"].collision_mask, space_collision_layer)
  collision_mask_util_extended.remove_layer(data.raw["assembling-machine"]["kr-electrolysis-plant-spaced"].collision_mask, space_collision_layer)
  collision_mask_util_extended.remove_layer(data.raw["assembling-machine"]["kr-electrolysis-plant"].collision_mask, spaceship_collision_layer)
  collision_mask_util_extended.remove_layer(data.raw["assembling-machine"]["kr-electrolysis-plant-spaced"].collision_mask, spaceship_collision_layer)
  data.raw["assembling-machine"]["kr-electrolysis-plant"].localised_description = {"entity-description.kr-electrolysis-plant"}
  data.raw["assembling-machine"]["kr-electrolysis-plant-spaced"].localised_description = {"space-exploration.structure_description_spaced", {"entity-description.kr-electrolysis-plant"}}

  -- make sure that it can't use productivity (true by default)
  --data.raw["assembling-machine"]["kr-electrolysis-plant"].allowed_effects = {"consumption", "speed", "pollution"}

  -- Correct Salt Water Electrolysis gas production ratios
  local electrolysis = data.raw.recipe["kr-water-electrolysis"]
  electrolysis.energy_required = 5
  electrolysis.results = {
	  {type = "fluid", name = "chlorine", amount = 20},
    {type = "fluid", name = "hydrogen", amount = 20},
  }
  data_util.disallow_productivity("kr-water-electrolysis")

  -- Correct Water Seperation gas production ratios
  local separation = data.raw.recipe["kr-water-separation"]
  separation.energy_required = 6
  separation.ingredients = {
    {type = "fluid", name = "water", amount = 60, catalyst_amount = 60}
  }
  separation.results = {
	  {type = "fluid", name = "oxygen", amount = 20},
    {type = "fluid", name = "hydrogen", amount = 40},
  }
  data_util.disallow_productivity("kr-water-separation")

  -- Correct Water Creation consumption ratios
  local water = data.raw.recipe["kr-water"]
  water.energy_required = 6
  water.ingredients = {
    {type = "fluid", name = "oxygen", amount = 20},
    {type = "fluid", name = "hydrogen", amount = 40},
  }
  water.results = {
    {type = "fluid", name = "water", amount = 60}
  }
  data_util.disallow_productivity("kr-water")

  -- Increase consumption of gaseous ingredients, add Oxygen and Hydrogen to Vulcanite recipe
  data_util.replace_or_add_ingredient("rocket-fuel", "light-oil", "light-oil", 100, true)
  data_util.replace_or_add_ingredient("rocket-fuel", "oxygen", "oxygen", 1000, true)
  data_util.replace_or_add_ingredient("rocket-fuel-with-ammonia", "ammonia", "ammonia", 1000, true)
  data_util.replace_or_add_ingredient("rocket-fuel-with-ammonia", "oxygen", "oxygen", 1000, true)
  data_util.replace_or_add_ingredient("rocket-fuel-with-hydrogen-chloride", "hydrogen-chloride", "hydrogen-chloride", 1000, true)
  data_util.replace_or_add_ingredient("rocket-fuel-with-hydrogen-chloride", "oxygen", "oxygen", 1000, true)
  data_util.replace_or_add_ingredient("se-vulcanite-rocket-fuel", nil, "iron-plate", 1)
  data_util.replace_or_add_ingredient("se-vulcanite-rocket-fuel", "oxygen", "oxygen", 500, true)

  -- remove electrolysis from biochem facility becuase it has a reduced energy cost per craft speed
  data_util.remove_from_table(data.raw["assembling-machine"]["se-space-biochemical-laboratory"].crafting_categories, "electrolysis")

  -- match the SE version to avoid infinite power exploits and cheap fuel
  local fuel_refinery = data.raw["assembling-machine"]["kr-fuel-refinery"]
  fuel_refinery.allowed_effects = {"consumption", "speed", "productivity", "pollution"}
  fuel_refinery.crafting_speed = 1
  fuel_refinery.energy_usage = "1000kW"

  fuel_refinery = data.raw["assembling-machine"]["kr-fuel-refinery-spaced"]
  fuel_refinery.allowed_effects = {"consumption", "speed", "pollution"}
  fuel_refinery.crafting_speed = 1
  fuel_refinery.energy_usage = "1000kW"
  if not data_util.table_contains(fuel_refinery.crafting_categories, "fuel-refining") then
    table.insert(fuel_refinery.crafting_categories, "fuel-refining")
  end
  fuel_refinery.localised_description = {"space-exploration.structure_description_spaced", ""}
  -- end rocket fuel energy fixes
  ----------------------------------------------------------------------------------------------------------------------


  -- fix k2 doing something to the lab
  for _, lab in pairs(data.raw.lab) do
    for i, item in pairs(lab.inputs) do
      if item == "se-deep-space-science-pack" then
        lab.inputs[i] = nil
      end
    end
  end

  -- fix power progression
  -- higher tech means more power density
  -- more complicated setups mean higher energy efficiency (closer to 1).
  -- simpler setups mean reduced energy efficiency.

  -- fuild isothermic generator is 0.75 normally
  -- both convert fuel to energy directly so shouldn't be over 80% efficiency.
  -- fuild isothermic generator is less space efficient.
  data.raw["generator"]["kr-gas-power-station"].energy_source.effectivity = 0.75
  data.raw["generator"]["kr-gas-power-station"].collsion_mask = --land
    {"item-layer","object-layer","player-layer","water-tile",space_collision_layer, spaceship_collision_layer}
  data.raw["generator"]["se-fluid-burner-generator"].collsion_mask = --space
    {"water-tile","ground-tile","item-layer","object-layer","player-layer"}

  data.raw["burner-generator"]["kr-antimatter-reactor"].burner.effectivity = 0.8
  data.raw["burner-generator"]["kr-antimatter-reactor"].max_power_output = "2GW"
  data.raw.item["charged-antimatter-fuel-cell"].fuel_value = "100GJ" --same as antimatter cell

  data.raw["burner-generator"]["kr-antimatter-reactor"].collsion_mask = --land, space, not spaceship
    {"item-layer","object-layer","player-layer","water-tile", spaceship_collision_layer}

  --Thanks to PeterHan5
  krastorio.recipes.replaceProduct("se-core-fragment-imersite", "raw-imersite", {type="item", name="raw-imersite", amount=10})
  krastorio.recipes.replaceProduct("se-core-fragment-rare-metals", "raw-rare-metals", {type="item", name="raw-rare-metals", amount=10})
  krastorio.recipes.replaceProduct("se-core-fragment-mineral-water", "mineral-water", {type="fluid", name="mineral-water", amount=50})
  krastorio.recipes.replaceProduct("se-core-fragment-crude-oil", "crude-oil", {type="fluid", name="crude-oil", amount=50})

  data_util.replace_or_add_ingredient("se-bio-sludge-from-wood", "wood", "wood", 50)
  data_util.replace_or_add_ingredient("se-bio-sludge-from-wood", "se-space-water", "se-space-water", 20, true)

  -- Biosluge balance
  local biomass_recipe = table.deepcopy(data.raw.recipe["se-bio-sludge-from-wood"])
  biomass_recipe.name = "se-bio-sludge-from-biomass"
  biomass_recipe.icons = {
    { icon = data.raw.fluid[data_util.mod_prefix .. "bio-sludge"].icon, scale = 1, icon_size = 64  },
    { icon = data.raw.item["biomass"].icon, scale = 0.75/2, icon_size = 64  },
  }
  biomass_recipe.localised_name = {"recipe-name.se-bio-sludge-from-biomass"}
  data:extend({biomass_recipe})
  data_util.replace_or_add_ingredient("se-bio-sludge-from-biomass", "wood", "biomass", 50)
  data_util.replace_or_add_ingredient("se-bio-sludge-from-biomass", "se-space-water", "se-space-water", 10, true)
  data_util.tech_lock_recipes("se-space-biochemical-laboratory", {"se-bio-sludge-from-biomass"})

  if data.raw["spider-vehicle"]["spidertron"].energy_source.fuel_categories then
    data_util.tech_add_prerequisites("spidertron", {"uranium-processing"})
    table.insert(data.raw["spider-vehicle"]["spidertron"].energy_source.fuel_categories, "nuclear")
  end

  -- Add appropriate collision masks for the Intergalactic Transciever entities
  for _, prototype in pairs({
    data.raw["accumulator"]["kr-intergalactic-transceiver"],
    data.raw["electric-energy-interface"]["kr-activated-intergalactic-transceiver"]}) do
    if not prototype.collision_mask then
      prototype.collision_mask = {"item-layer","object-layer","player-layer","water-tile"}
    end
    if not data_util.table_contains(prototype.collision_mask, spaceship_collision_layer) then
      table.insert(prototype.collision_mask, spaceship_collision_layer)
    end
  end

  -- Disable SE Spaceship Victory tech. Enabled via script in space-explortation/scripts/compatibility/krastorio2
  if data.raw.technology["se-spaceship-victory"] then
    data_util.tech_add_prerequisites("se-spaceship-victory",{"kr-intergalactic-transceiver"})
    data.raw.technology["se-spaceship-victory"].enabled = false
  end

  move_to_specialist_science_packs("kr-advanced-tank", {"se-material-science-pack-2"})
  data_util.tech_add_ingredients("kr-advanced-tank", {"military-science-pack"}, true)

  move_to_specialist_science_packs("kr-creep-virus", {"se-biological-science-pack-1"})
  move_to_specialist_science_packs("kr-biter-virus", {"se-biological-science-pack-3"})

  -- Require files where further directed changes are made
  require("prototypes/phase-4/krastorio2/matter")
  require("prototypes/phase-4/krastorio2/infinite-techs")
  require("prototypes/phase-4/krastorio2/singularity")
  require("prototypes/phase-4/krastorio2/inserters")
  require("prototypes/phase-4/krastorio2/washing")
  require("prototypes/phase-4/krastorio2/equipment")
  require("prototypes/phase-4/krastorio2/intermediaries")
  require("prototypes/phase-4/krastorio2/entity")

end
