local data_util = require("data_util")

-- This source is dedicated to integrating SE's and K2's equipments

-- Allow Jackhammer to collect Space Platform Scaffolding and Plating
table.insert(data.raw["selection-tool"]["kr-jackhammer"].tile_filters,"se-space-platform-scaffold")
table.insert(data.raw["selection-tool"]["kr-jackhammer"].alt_tile_filters,"se-space-platform-scaffold")
table.insert(data.raw["selection-tool"]["kr-jackhammer"].tile_filters,"se-space-platform-plating")
table.insert(data.raw["selection-tool"]["kr-jackhammer"].alt_tile_filters,"se-space-platform-plating")

---- Radars
if data.raw.technology["kr-radar"] then
  data.raw.technology["kr-radar"].prerequisites = {"optics"}
  data_util.tech_remove_ingredients("kr-radar", {"logistic-science-pack"})
end

if data.raw.technology["advanced-radar"] then
  data.raw.technology["advanced-radar"].prerequisites = {"laser", data.raw.technology["kr-radar"] and "kr-radar" or nil}
  data_util.tech_add_ingredients("advanced-radar", {"chemical-science-pack"})
  data_util.tech_remove_ingredients("advanced-rada", {"singularity-tech-card"})
end


-- Seperate Imersite Weapons away from K2 Military Tech 5 into new Imersite Weapons tech
if data.raw.technology["kr-military-5"] then
  local tech = table.deepcopy(data.raw.technology["kr-military-5"])
  tech.name = "kr-imersite-weapons"
  tech.effects = {}
  tech.prerequisites = {
    "kr-military-5",
    "kr-imersium-processing",
    "kr-advanced-tech-card",
  }
  tech.unit.ingredients = {
      {"production-science-pack", 1},
      {"utility-science-pack", 1},
      {"military-science-pack", 1},
      {"advanced-tech-card", 1},
  }
  data:extend({tech})
  data_util.tech_lock_recipes("kr-imersite-weapons", {"impulse-rifle", "impulse-rifle-ammo", "imersite-rifle-magazine", "imersite-anti-material-rifle-magazine"})
  data_util.replace_or_add_ingredient("impulse-rifle", "steel-plate", "imersium-plate", 5)
end

---- Medical Items
-- First Aid Kit
data_util.enable_recipe("first-aid-kit")
data.raw.capsule["first-aid-kit"].subgroup = "tool"
data.raw.capsule["first-aid-kit"].order = "a"
data.raw.capsule["first-aid-kit"].stack_size = 20
data.raw.capsule["first-aid-kit"].capsule_action = {
  attack_parameters = {
    ammo_category = "capsule",
    ammo_type = {
      action = {
        action_delivery = {
          target_effects = {
            damage = {
              amount = -25,
              type = "poison"
            },
            type = "damage"
          },
          type = "instant"
        },
        type = "direct"
      },
      category = "capsule",
      target_type = "position"
    },
    cooldown = 10,
    range = 0,
    type = "projectile"
  },
  type = "use-on-self"
}

-- Alt First Aid Kit
local first_aid_kit_2 = table.deepcopy(data.raw.recipe["first-aid-kit"])
first_aid_kit_2.name = "first-aid-kit-fish"
data:extend({first_aid_kit_2})
data_util.replace_or_add_ingredient("first-aid-kit-fish", "biomass", "raw-fish", 1)

-- Medpack 1
data_util.replace_or_add_ingredient("se-medpack", "iron-plate", "first-aid-kit", 1)
data_util.replace_or_add_ingredient("se-medpack", "wood", "wood", 2)
data_util.replace_or_add_ingredient("se-medpack", "raw-fish", "raw-fish", 1)
data_util.replace_or_add_ingredient("se-medpack", "biomass", "biomass", 1)

-- Alt Medpack 1
data_util.replace_or_add_ingredient("se-medpack-plastic", "iron-plate", "first-aid-kit", 1)

---- Ammo
-- Tesla Gun Ammo
data_util.replace_or_add_ingredient("se-tesla-ammo", "battery", "lithium-sulfur-battery", 10)

---- Power Armours
-- Power Armour Mk3
data_util.tech_remove_ingredients("kr-power-armor-mk3", {"advanced-tech-card"})
data_util.tech_remove_prerequisites("kr-power-armor-mk3", {"kr-advanced-tech-card"})
data_util.tech_add_ingredients("kr-power-armor-mk3", {"military-science-pack","chemical-science-pack","production-science-pack","se-rocket-science-pack","se-material-science-pack-1","se-energy-science-pack-1"})
data_util.tech_add_prerequisites("kr-power-armor-mk3", {"se-material-science-pack-1","se-energy-science-pack-1"})
data_util.replace_or_add_ingredient("power-armor-mk3", nil, "se-iridium-plate", 25)

--Power Armour Mk4
data_util.tech_remove_ingredients("kr-power-armor-mk4", {"singularity-tech-card"})
data_util.tech_remove_prerequisites("kr-power-armor-mk4", {"kr-singularity-tech-card"})
data_util.tech_add_ingredients("kr-power-armor-mk4", {"military-science-pack","chemical-science-pack","production-science-pack","se-rocket-science-pack","se-material-science-pack-3","se-energy-science-pack-3"})
data_util.tech_add_prerequisites("kr-power-armor-mk4", {"kr-advanced-tech-card"})
data_util.replace_or_add_ingredient("power-armor-mk4", "ai-core", "ai-core", 10)
data_util.replace_or_add_ingredient("power-armor-mk4", "nitric-acid", "se-quantum-processor", 30)
data_util.replace_or_add_ingredient("power-armor-mk4", "imersite-crystal", "energy-control-unit", 15)
data_util.replace_or_add_ingredient("power-armor-mk4", "imersium-plate", "imersium-plate", 15)
data_util.replace_or_add_ingredient("power-armor-mk4", nil, "se-heavy-composite", 20)
data_util.replace_or_add_ingredient("power-armor-mk4", nil, "se-heavy-bearing", 5)

---- Thruster Suits
-- Thruster Suit 3
data_util.tech_add_ingredients("se-thruster-suit-3", {"advanced-tech-card"})
data_util.tech_add_prerequisites("se-thruster-suit-3", {"kr-advanced-tech-card"})
data_util.replace_or_add_ingredient("thruster-suit-3", "processing-unit", "processing-unit", 50)
data_util.replace_or_add_ingredient("thruster-suit-3", nil, "energy-control-unit", 20)

-- Thruster Suit 4
data_util.replace_or_add_ingredient("thruster-suit-4", "processing-unit", "processing-unit", 100)
data_util.replace_or_add_ingredient("thruster-suit-4", nil, "energy-control-unit", 30)
data_util.replace_or_add_ingredient("thruster-suit-4", nil, "ai-core", 5)

---- Batteries
-- Personal Battery Mk3
data_util.tech_remove_prerequisites("kr-battery-mk3-equipment", {"kr-quarry-minerals-extraction"})
data_util.tech_add_prerequisites("kr-battery-mk3-equipment", {"production-science-pack"})

---- Lasers
-- Personal Laser Defence Mk3
data_util.tech_remove_ingredients("kr-personal-laser-defense-mk3-equipment", {"advanced-tech-card"})
data_util.tech_remove_prerequisites("kr-personal-laser-defense-mk3-equipment", {"kr-advanced-tech-card"})
data_util.tech_add_ingredients("kr-personal-laser-defense-mk3-equipment", {"military-science-pack","production-science-pack","space-science-pack","se-rocket-science-pack","se-energy-science-pack-2"})
data_util.tech_add_prerequisites("kr-personal-laser-defense-mk3-equipment", {"se-energy-science-pack-2"})

-- Personal Laser Defense Mk4
data_util.tech_remove_ingredients("kr-personal-laser-defense-mk4-equipment", {"singularity-tech-card"})
data_util.tech_remove_prerequisites("kr-personal-laser-defense-mk4-equipment", {"kr-singularity-tech-card"})
data_util.tech_add_ingredients("kr-personal-laser-defense-mk4-equipment", {"military-science-pack","production-science-pack","se-rocket-science-pack","se-energy-science-pack-4"})
data_util.tech_add_prerequisites("kr-personal-laser-defense-mk4-equipment", {"kr-advanced-tech-card","se-energy-science-pack-4"})

---- Exoskeleton
-- Advanced Exoskeleton
data_util.tech_add_prerequisites("kr-advanced-exoskeleton-equipment", {"production-science-pack"})
data_util.tech_add_ingredients("kr-advanced-exoskeleton-equipment", {"production-science-pack"})
data_util.replace_or_add_ingredient("advanced-exoskeleton-equipment", "advanced-circuit", "processing-unit", 10)
data_util.replace_or_add_ingredient("advanced-exoskeleton-equipment", "speed-module-2", "speed-module-3", 10)
data_util.replace_or_add_ingredient("advanced-exoskeleton-equipment", nil, "lubricant", 10, true)
data.raw.recipe["advanced-exoskeleton-equipment"].category = "crafting-with-fluid"

-- Superiror Exoskeleton
data_util.tech_remove_prerequisites("kr-superior-exoskeleton-equipment", {"kr-advanced-tech-card"})
data_util.tech_remove_ingredients("kr-superior-exoskeleton-equipment", {"advanced-tech-card"})
data_util.tech_add_prerequisites("kr-superior-exoskeleton-equipment", {"production-science-pack","se-astronomic-science-pack-2","se-material-science-pack-2"})
data_util.tech_add_ingredients("kr-superior-exoskeleton-equipment", {"production-science-pack","se-astronomic-science-pack-2","se-material-science-pack-2"})
data_util.replace_or_add_ingredient("superior-exoskeleton-equipment", "ai-core", "se-aeroframe-scaffold", 10)
data_util.replace_or_add_ingredient("superior-exoskeleton-equipment", "speed-module-3", "speed-module-5", 10)
data_util.replace_or_add_ingredient("superior-exoskeleton-equipment", nil, "se-heavy-bearing", 10)
data_util.replace_or_add_ingredient("superior-exoskeleton-equipment", nil, "processing-unit", 20)

---- Nightvision
-- Imersite Nightvision
data_util.tech_add_prerequisites("kr-imersite-night-vision-equipment", {"production-science-pack","se-rocket-science-pack"})
data_util.tech_add_ingredients("kr-imersite-night-vision-equipment", {"production-science-pack","se-rocket-science-pack"})

---- Adaptive Armor
-- Adaptive Armor 3
data_util.replace_or_add_ingredient("se-adaptive-armour-equipment-3",nil,"lithium-sulfur-battery",5)

-- Adaptive Armor 4
data_util.tech_add_prerequisites("se-adaptive-armour-equipment-4", {"kr-imersium-processing"})
data_util.replace_or_add_ingredient("se-adaptive-armour-equipment-4", "steel-plate", "imersium-plate", 20)

-- Adaptive Armor 5
data_util.tech_add_prerequisites("se-adaptive-armour-equipment-5", {"kr-advanced-tech-card"})
data_util.tech_add_ingredients("se-adaptive-armour-equipment-5", {"advanced-tech-card"})
data_util.replace_or_add_ingredient("se-adaptive-armour-equipment-5", "processing-unit", "processing-unit", 20)
data_util.replace_or_add_ingredient("se-adaptive-armour-equipment-5", "steel-plate", "imersium-plate", 40)
data_util.replace_or_add_ingredient("se-adaptive-armour-equipment-5", nil, "energy-control-unit", 5)

---- Shields
-- Clean up unused K2 alternate recipes and techs.
data.raw.technology["kr-energy-shield-mk3-equipment"] = nil
data.raw.recipe["energy-shield-mk3-equipment-2"] = nil
data.raw.technology["kr-energy-shield-mk4-equipment"] = nil
data.raw.recipe["energy-shield-mk4-equipment-2"] = nil

-- Energy Shield Mk1
data.raw.technology["energy-shield-equipment"].prerequisites = {"se-holmium-cable", "military-science-pack", "se-adaptive-armour-2"}
data.raw.technology["energy-shield-equipment"].unit.ingredients = { {"military-science-pack", 1}, {"se-energy-science-pack-1", 1}}
krastorio.icons.setTechnologyIcon("energy-shield-equipment", "__space-exploration-graphics__/graphics/technology/energy-shield-red.png", 128, 0)
data.raw.item["energy-shield-equipment"].order = "s[energy-shield]-s1[energy-shield]"
data.raw.item["energy-shield-equipment"].subgroup = "character-equipment"
data.raw.item["energy-shield-equipment"].icons = nil
data.raw.item["energy-shield-equipment"].icon = "__space-exploration-graphics__/graphics/icons/energy-shield-red.png"
data.raw.item["energy-shield-equipment"].icon_size = 64
data.raw["energy-shield-equipment"]["energy-shield-equipment"].sprite.filename = "__space-exploration-graphics__/graphics/equipment/energy-shield-red.png"
data.raw["energy-shield-equipment"]["energy-shield-equipment"].sprite.width = 64
data.raw["energy-shield-equipment"]["energy-shield-equipment"].sprite.height = 64
data.raw["energy-shield-equipment"]["energy-shield-equipment"].sprite.hr_version = nil

-- Energy Shield Mk2
data.raw.technology["energy-shield-mk2-equipment"].unit.ingredients = { {"military-science-pack", 1}, {"se-energy-science-pack-2", 1}}
krastorio.icons.setTechnologyIcon("energy-shield-mk2-equipment", "__space-exploration-graphics__/graphics/technology/energy-shield-yellow.png", 128, 0)
data.raw.item["energy-shield-mk2-equipment"].order = "s[energy-shield]-s2[energy-shield]"
data.raw.item["energy-shield-mk2-equipment"].subgroup = "character-equipment"
data.raw.item["energy-shield-mk2-equipment"].icons = nil
data.raw.item["energy-shield-mk2-equipment"].icon = "__space-exploration-graphics__/graphics/icons/energy-shield-yellow.png"
data.raw.item["energy-shield-mk2-equipment"].icon_size = 64
data.raw["energy-shield-equipment"]["energy-shield-mk2-equipment"].sprite.filename = "__space-exploration-graphics__/graphics/equipment/energy-shield-yellow.png"
data.raw["energy-shield-equipment"]["energy-shield-mk2-equipment"].sprite.width = 64
data.raw["energy-shield-equipment"]["energy-shield-mk2-equipment"].sprite.height = 64
data.raw["energy-shield-equipment"]["energy-shield-mk2-equipment"].sprite.hr_version = nil

-- Energy Shield Mk3
data.raw.technology["energy-shield-mk3-equipment"].unit.ingredients = { {"military-science-pack", 1}, {"se-energy-science-pack-3", 1}}
data.raw.item["energy-shield-mk3-equipment"].order = "s[energy-shield]-s3[energy-shield]"
data.raw.item["energy-shield-mk3-equipment"].subgroup = "character-equipment"
data.raw.item["energy-shield-mk3-equipment"].icons = nil
data.raw.item["energy-shield-mk3-equipment"].icon = "__space-exploration-graphics__/graphics/icons/energy-shield-green.png"
data.raw.item["energy-shield-mk3-equipment"].icon_size = 64
data.raw["energy-shield-equipment"]["energy-shield-mk3-equipment"].sprite.filename = "__space-exploration-graphics__/graphics/equipment/energy-shield-green.png"
data.raw["energy-shield-equipment"]["energy-shield-mk3-equipment"].sprite.width = 64
data.raw["energy-shield-equipment"]["energy-shield-mk3-equipment"].sprite.height = 64
data.raw["energy-shield-equipment"]["energy-shield-mk3-equipment"].sprite.hr_version = nil

-- Energy Shield Mk4
data.raw.technology["energy-shield-mk4-equipment"].unit.ingredients = { {"military-science-pack", 1}, {"se-energy-science-pack-4", 1}}
data.raw.item["energy-shield-mk4-equipment"].order = "s[energy-shield]-s4[energy-shield]"
data.raw.item["energy-shield-mk4-equipment"].subgroup = "character-equipment"
data.raw.item["energy-shield-mk4-equipment"].icons = nil
data.raw.item["energy-shield-mk4-equipment"].icon = "__space-exploration-graphics__/graphics/icons/energy-shield-cyan.png"
data.raw.item["energy-shield-mk4-equipment"].icon_size = 64
data.raw["energy-shield-equipment"]["energy-shield-mk4-equipment"].sprite.filename = "__space-exploration-graphics__/graphics/equipment/energy-shield-cyan.png"
data.raw["energy-shield-equipment"]["energy-shield-mk4-equipment"].sprite.width = 64
data.raw["energy-shield-equipment"]["energy-shield-mk4-equipment"].sprite.height = 64
data.raw["energy-shield-equipment"]["energy-shield-mk4-equipment"].sprite.hr_version = nil

-- Energy Shield Mk5
data_util.tech_add_prerequisites("energy-shield-mk5-equipment", { "se-deep-space-science-pack-1"})
data.raw.technology["energy-shield-mk5-equipment"].unit.ingredients = { {"military-science-pack", 1}, {"se-energy-science-pack-4", 1}, {"se-deep-space-science-pack-1", 1}}

-- Energy Shield Mk6
data_util.tech_add_prerequisites("energy-shield-mk6-equipment", {"kr-singularity-tech-card"})
data.raw.technology["energy-shield-mk6-equipment"].unit.ingredients = {{"military-science-pack", 1}, {"se-energy-science-pack-4", 1}, {"se-deep-space-science-pack-4", 1}, {"singularity-tech-card", 1}}
