local data_util = require("data_util")
-- Suggested Philosophy for Singularity in K2SE context:
-- Singularity Tech is the improvements of current technology with Arcosphere physics bending insights

-- Possible Future Idea
-- Create item 'Arcosphere Folding Observation Data' produced by acrosphere folding processes
-- Consume this item in more 'efficient' arcosphere folding recipes and the Singularity tech card
-- -- or --
-- Create multiple alternative singularity tech card recipes that switch much as the arcosphere
-- folding recipes do, each one requiring a specific polarisation of arcosphere?

-- Move Singularity Card to be unlocked by Deep Space Science Pack 3
data_util.tech_remove_prerequisites("kr-singularity-tech-card",{"space-science-pack","kr-matter-processing","se-deep-space-science-pack-4"})
data_util.tech_remove_ingredients("kr-singularity-tech-card",{"se-deep-space-science-pack-4"})
data_util.tech_add_prerequisites("kr-singularity-tech-card",{"se-deep-space-science-pack-3"})
data_util.tech_add_ingredients("kr-singularity-tech-card",{"se-deep-space-science-pack-3"})


if data.raw.recipe["singularity-tech-card"] then
  local card = data.raw.recipe["singularity-tech-card"]
  card.category = "arcosphere"
  card.energy_required = 180
  card.allow_productivity = false
  card.ingredients = {
    {"se-deep-space-science-pack-3" , 6},
    {"se-significant-data", 1},
    {"ai-core", 1},
    {"se-arcosphere-a", 1}, -- lambda
    --{"se-arcosphere-b", 0}, -- xi
    --{"se-arcosphere-c", 0}, -- zeta
    {"se-arcosphere-d", 1}, -- theta
    {"se-arcosphere-e", 1}, -- epsilon
    --{"se-arcosphere-f", 0}, -- phi
    --{"se-arcosphere-g", 0}, -- gamma
    {"se-arcosphere-h", 1}, -- omega
    { type = "fluid", name = data_util.mod_prefix .. "space-coolant-supercooled", amount = 200}
  }
  card.result = nil
  card.result_count = nil
  card.results = {
    {"singularity-tech-card", 8},
    {"se-junk-data", 4},
    {"se-broken-data", 1},
    { type = "fluid", name = data_util.mod_prefix .. "space-coolant-hot", amount = 200},
    {"se-arcosphere-a", 1}, -- lambda
    {"se-arcosphere-b", 0}, -- xi
    {"se-arcosphere-c", 1}, -- zeta
    {"se-arcosphere-d", 0}, -- theta
    {"se-arcosphere-e", 1}, -- epsilon
    {"se-arcosphere-f", 0}, -- phi
    {"se-arcosphere-g", 1}, -- gamma
    {"se-arcosphere-h", 0}, -- omega
  }
  card.main_product = "singularity-tech-card"
  card.always_show_made_in = true
end

local card_alt = table.deepcopy(data.raw.recipe["singularity-tech-card"])
card_alt.name = "singularity-tech-card-alt"
card_alt.ingredients = {
  {"se-deep-space-science-pack-3" , 6},
  {"se-significant-data", 1},
  {"ai-core", 1},
  {"se-arcosphere-a", 1}, -- lambda
  --{"se-arcosphere-b", 0}, -- xi
  --{"se-arcosphere-c", 0}, -- zeta
  {"se-arcosphere-d", 1}, -- theta
  {"se-arcosphere-e", 1}, -- epsilon
  --{"se-arcosphere-f", 0}, -- phi
  --{"se-arcosphere-g", 0}, -- gamma
  {"se-arcosphere-h", 1}, -- omega
  { type = "fluid", name = data_util.mod_prefix .. "space-coolant-supercooled", amount = 200}
}
card_alt.results = {
  {"singularity-tech-card", 8},
  {"se-junk-data", 4},
  {"se-broken-data", 1},
  { type = "fluid", name = data_util.mod_prefix .. "space-coolant-hot", amount = 200},
  {"se-arcosphere-a", 0}, -- lambda
  {"se-arcosphere-b", 1}, -- xi
  {"se-arcosphere-c", 0}, -- zeta
  {"se-arcosphere-d", 1}, -- theta
  {"se-arcosphere-e", 0}, -- epsilon
  {"se-arcosphere-f", 1}, -- phi
  {"se-arcosphere-g", 0}, -- gamma
  {"se-arcosphere-h", 1}, -- omega
}
card_alt.icon = "__Krastorio2Assets__/icons/cards/singularity-tech-card.png"
card_alt.icon_size = 64
card_alt.icon_mipmaps = 4
card_alt.subgroup = "science-pack"
card_alt.order = "b11[singularity-tech-card]"
data:extend({card_alt})
table.insert(data.raw.technology["kr-singularity-tech-card"].effects, { type = "unlock-recipe", recipe = "singularity-tech-card-alt"})

-- Singularity Lab Tech
data_util.tech_remove_prerequisites("kr-singularity-lab",{"kr-quantum-computer"})
data_util.tech_remove_ingredients("kr-singularity-lab",{"automation-science-pack","logistic-science-pack","chemical-science-pack","kr-deep-space-science-pack-1"})
data_util.tech_add_prerequisites("kr-singularity-lab",{"kr-singularity-tech-card"})
data_util.tech_add_ingredients("kr-singularity-lab",{"space-science-pack","advanced-tech-card","matter-tech-card","se-deep-space-science-pack-3","singularity-tech-card"})

-- Singularity Lab Recipe
data.raw.recipe["kr-singularity-lab"].category = "space-manufacturing"
data.raw.recipe["kr-singularity-lab"].ingredients = { -- this needs to change too much to make item by item changes
  {"se-space-science-lab", 1},
  {"se-space-radiator-2",8},
  {"se-space-hypercooler",2},
  {"se-naquium-tessaract", 4},
  {"ai-core", 50}, -- Biological
  {"se-heavy-composite",50}, -- Material
  {"se-dynamic-emitter",50}, -- Energy
  {"se-nanomaterial",50}, -- Astronomic
  { type = "fluid", name = "se-space-coolant-supercooled", amount = 2000},
}

-- Singularity Lab Entity
if data.raw["lab"]["kr-singularity-lab"] then
  local adv_lab = data.raw["lab"]["biusart-lab"]
  local se_lab = data.raw["lab"]["se-space-science-lab"]
  local k2_lab = data.raw["lab"]["kr-singularity-lab"]

  -- Stagger lab stats
  if adv_lab then
    adv_lab.researching_speed = 1.5 -- was 1
    adv_lab.module_specification.module_slots = 3 -- was 2
  end

  se_lab.researching_speed = 5 -- was 10
  se_lab.module_specification.module_slots = 6 -- was 6

  k2_lab.researching_speed = 10 -- 2x SE version
  k2_lab.module_specification.module_slots = 8 -- was 4
  -- With SE Speed Module 9s in a Singularity Beacon, this consumes ~289 spm
  -- With SE Speed Module 9s in a Singularity Beacon, Space Sciecne Laboratory consumes ~162 spm

  -- Ensure Singularity Lab can host all K2SE Science Packs and all Packs it had previously,
  local prior_tech_cards = data.raw.lab["kr-singularity-lab"].inputs
  local k2se_tech_cards = {
    "basic-tech-card",
    "automation-science-pack",
    "logistic-science-pack",
    "military-science-pack",
    "chemical-science-pack",
    "production-science-pack",
    "utility-science-pack",
    "se-rocket-science-pack",
    "space-science-pack",
    "se-astronomic-science-pack-1",
    "se-astronomic-science-pack-2",
    "se-astronomic-science-pack-3",
    "se-astronomic-science-pack-4",
    "se-biological-science-pack-1",
    "se-biological-science-pack-2",
    "se-biological-science-pack-3",
    "se-biological-science-pack-4",
    "se-energy-science-pack-1",
    "se-energy-science-pack-2",
    "se-energy-science-pack-3",
    "se-energy-science-pack-4",
    "se-material-science-pack-1",
    "se-material-science-pack-2",
    "se-material-science-pack-3",
    "se-material-science-pack-4",
    "advanced-tech-card",
    "matter-tech-card",
    "se-deep-space-science-pack-1",
    "se-deep-space-science-pack-2",
    "se-deep-space-science-pack-3",
    "se-deep-space-science-pack-4",
    "singularity-tech-card"
  }

  for _, input in pairs(prior_tech_cards) do
    if not data_util.table_contains(k2se_tech_cards, input) then
      table.insert(k2se_tech_cards, input)
    end
  end

  k2_lab.inputs = k2se_tech_cards
end

-- Add Singularity Tech Card to Teleportation Tech
data_util.tech_add_prerequisites("se-teleportation",{"kr-singularity-tech-card"})
data_util.tech_add_ingredients("se-teleportation",{"space-science-pack","advanced-tech-card","singularity-tech-card"})

-- Move K2 Planetary Teleporter to require SE Teleportation Tech
data_util.tech_remove_prerequisites("kr-planetary-teleporter",{"effect-transmission"})
data_util.tech_add_prerequisites("kr-planetary-teleporter",{"se-teleportation"})

-- Bring K2 Planetary Teleporter recipe closer in line with Arcolink Chest
-- No arcospheres due to same-surface restriction that currently exists?
data.raw.recipe["kr-planetary-teleporter"].ingredients = { -- this needs to change too much to make item by item changes
  {"se-nanomaterial", 10},
  {"se-lattice-pressure-vessel",10},
  {"se-heavy-assembly", 10},
  {"se-self-sealing-gel", 10},
  {"energy-control-unit", 10},
  {"se-dynamic-emitter", 10},
  {"se-naquium-processor", 10},
  {"teleportation-gps-module", 1}
}
