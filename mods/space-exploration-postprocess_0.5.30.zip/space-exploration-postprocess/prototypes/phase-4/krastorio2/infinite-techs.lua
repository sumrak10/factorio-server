-- This source is dedicated to integrating SEs and K2s competing changes to infinite technologies.

-- Infinite Techs SE Flavour:
---- Artillery Shell Range - Material
---- Artillery Shell Shooting Speed - Material 
---- Mining Productivity - Biological
---- Energy Weapons Damage - Energy
---- Worker Robot Speed - Energy
---- Physical Projectile Damage - Material
---- Refined Flammables - Material
---- Stronger Explosives - Material
---- Follower Robot Count - Material
---- Factory Spaceship - All bar Biological
---- Rocket Cargo Safety - Astronomic
---- Rocket Survivability - Astronomic

local data_util = require("data_util")

local function move_technology(tech_name, techs_to_add, ingredients_to_add, techs_to_remove, ingredients_to_remove)
  if ingredients_to_remove then
    data_util.tech_remove_ingredients(tech_name, ingredients_to_remove)
  end
  if techs_to_remove then
    data_util.tech_remove_prerequisites(tech_name, techs_to_remove)
  end
  if ingredients_to_add then
    data_util.tech_add_ingredients(tech_name, ingredients_to_add)
  end
  if techs_to_add then
    data_util.tech_add_prerequisites(tech_name, techs_to_add)
  end
end

-- Check whether a technology is infinite
local function tech_is_infinite(tech_name)
  local i = 1
  while data.raw.technology[tech_name.."-"..i] do
    if data.raw.technology[tech_name.."-"..i].max_level == "infinite" then
      return true
    else
      if data.raw.technology[tech_name.."-"..i].max_level then
        i = data.raw.technology[tech_name.."-"..i].max_level + 1
      else
        i = i + 1
      end
    end
  end
  return false
end

-- If a technology is not infinite, make it infinite  
local function make_tech_infinite(tech_name)
  local i = 1
  local last_tech
  if not tech_is_infinite(tech_name) then
    while data.raw.technology[tech_name.."-"..i] do
      last_tech = data.raw.technology[tech_name.."-"..i]
      if last_tech.max_level then
        i = last_tech.max_level + 1
      else
        i = i + 1
      end
    end
    if last_tech then
      last_tech.max_level = "infinite"
      last_tech.unit.count = nil
	  last_tech.unit.count_formula = last_tech.unit.count_formula or "2^(L-7)*1000"
    end
  end
end

-- Krastorio has removed the infinite techs from the base game
if not krastorio.general.getSafeSettingValue("kr-infinite-technology") then
  make_tech_infinite("artillery-shell-range")
  make_tech_infinite("artillery-shell-speed")
  make_tech_infinite("energy-weapons-damage")
  make_tech_infinite("mining-productivity")
  make_tech_infinite("worker-robots-speed")
  make_tech_infinite("physical-projectile-damage")
  make_tech_infinite("refined-flammables")
  make_tech_infinite("stronger-explosives")
  make_tech_infinite("follower-robot-count")
end

-- Due to the longer pre-space phase with K2SE, we give some additional technology levels pre-"se-rocket-science-pack".
-- Artillery Shell Range requires three additional technologies for the tech pack progression
data_util.tech_split_at_levels("artillery-shell-range",{8,9,10})
-- Artillery Shell Firing Speed requires three additional technologies for the tech pack progression
data_util.tech_split_at_levels("artillery-shell-speed",{8,9,10})
-- Energy Weapons Damage requies the group at 11-15 to be broken up, and techs after level 12 removed, and to be made infinite again
data_util.tech_split_at_levels("energy-weapons-damage",{12,13})
data.raw.technology["energy-weapons-damage-13"] = nil
data.raw.technology["energy-weapons-damage-16"] = nil
make_tech_infinite("energy-weapons-damage")
-- Mining Productivity requires the group at 13-15 to be broken up.
data_util.tech_split_at_levels("mining-productivity",{14,15})
-- Physical Projectile Damage requires the group at 11-15 to be broken up, and the techs after level 12 removed, and to be made infinite again
data_util.tech_split_at_levels("physical-projectile-damage",{12,13})
data.raw.technology["physical-projectile-damage-13"] = nil
data.raw.technology["physical-projectile-damage-16"] = nil
make_tech_infinite("physical-projectile-damage")
-- Refined Flammables requires the group at 11-15 to be broken up, and the techs after level 12 removed, and to be made infinite again
data_util.tech_split_at_levels("refined-flammables",{12,13})
data.raw.technology["refined-flammables-13"] = nil
data.raw.technology["refined-flammables-16"] = nil
make_tech_infinite("refined-flammables")
-- Stronger Explosives requires the group at 11-15 to be broken up, and the techs after level 12 removed, and to be made infinite again
data_util.tech_split_at_levels("stronger-explosives",{12,13})
data.raw.technology["stronger-explosives-13"] = nil
data.raw.technology["stronger-explosives-16"] = nil
make_tech_infinite("stronger-explosives")
-- Follower Robot Count required two additional technologies for the tech pack progression
data_util.tech_split_at_levels("follower-robot-count",{11,12})

---- Re-integrate Material Science into Artillery Shell Range. 
move_technology(
	"artillery-shell-range-3",
	{"se-rocket-science-pack"},
	{"military-science-pack","se-rocket-science-pack"},
	{"kr-matter-tech-card","space-science-pack","kr-advanced-tech-card"},
	{"matter-tech-card","space-science-pack","advanced-tech-card"}
)

-- Material Science 1
move_technology(
	"artillery-shell-range-4",
	{"se-material-science-pack-1"},
	{"military-science-pack","se-rocket-science-pack","se-material-science-pack-1"},
	{"kr-matter-tech-card","kr-advanced-tech-card"},
	{"matter-tech-card","advanced-tech-card","space-science-pack"}
)

-- Optimization Tech Card
move_technology(
	"artillery-shell-range-5",
	{"space-science-pack"},
	{"military-science-pack","se-rocket-science-pack","space-science-pack"},
	{"kr-matter-tech-card","kr-advanced-tech-card","kr-singularity-tech-card"},
	{"matter-tech-card","advanced-tech-card","singularity-tech-card"}
)

-- Material Science 2
move_technology(
	"artillery-shell-range-6",
	{"se-material-science-pack-2"},
	{"military-science-pack","se-rocket-science-pack","se-material-science-pack-2"},
	{"kr-matter-tech-card","kr-advanced-tech-card","kr-singularity-tech-card"},
	{"matter-tech-card","advanced-tech-card","singularity-tech-card"}
)

-- Material Science 3
move_technology(
	"artillery-shell-range-7",
	{"se-material-science-pack-3"},
	{"military-science-pack","se-rocket-science-pack","se-material-science-pack-3"},
	{"kr-matter-tech-card","kr-advanced-tech-card","kr-singularity-tech-card"},
	{"matter-tech-card","advanced-tech-card","singularity-tech-card"}
)

-- Advanced Tech Card
move_technology(
	"artillery-shell-range-8",
	{"kr-advanced-tech-card"},
	{"military-science-pack","se-rocket-science-pack","advanced-tech-card","se-material-science-pack-3"},
	{"kr-matter-tech-card","kr-singularity-tech-card","se-material-science-pack-4"},
	{"matter-tech-card","singularity-tech-card"}
)

-- Material Science 4
move_technology(
	"artillery-shell-range-9",
	{"se-material-science-pack-4"},
	{"military-science-pack","se-rocket-science-pack","se-material-science-pack-4"},
	{"kr-matter-tech-card","kr-singularity-tech-card","se-deep-space-science-pack-1"},
	{"matter-tech-card","singularity-tech-card","se-deep-space-science-pack-1"}
)

-- Deep Space Science 1
move_technology(
	"artillery-shell-range-10",
	{"se-deep-space-science-pack-1"},
	{"military-science-pack","se-rocket-science-pack","se-deep-space-science-pack-1","se-material-science-pack-4"},
	{"kr-matter-tech-card","kr-singularity-tech-card"},
	{"matter-tech-card","singularity-tech-card"}
)

---- Re-integrate Material Science into Artillery Shell Shooting Speed.
move_technology(
	"artillery-shell-speed-3",
	{"se-rocket-science-pack"},
	{"military-science-pack","se-rocket-science-pack"},
	{"kr-matter-tech-card","space-science-pack","kr-advanced-tech-card"},
	{"matter-tech-card","space-science-pack","advanced-tech-card"}
)

-- Material Science 1
move_technology(
	"artillery-shell-speed-4",
	{"se-material-science-pack-1"},
	{"military-science-pack","se-rocket-science-pack","se-material-science-pack-1"},
	{"kr-matter-tech-card","kr-advanced-tech-card","space-science-pack"},
	{"matter-tech-card","advanced-tech-card"}
)

-- Optimization Tech Card
move_technology(
	"artillery-shell-speed-5",
	{"space-science-pack"},
	{"military-science-pack","se-rocket-science-pack","se-material-science-pack-1","space-science-pack"},
	{"kr-matter-tech-card","kr-advanced-tech-card","kr-singularity-tech-card"},
	{"matter-tech-card","advanced-tech-card","singularity-tech-card"}
)

-- Material Science 2
move_technology(
	"artillery-shell-speed-6",
	{"se-material-science-pack-2"},
	{"military-science-pack","se-rocket-science-pack","se-material-science-pack-2"},
	{"kr-matter-tech-card","kr-advanced-tech-card","kr-singularity-tech-card"},
	{"matter-tech-card","advanced-tech-card","singularity-tech-card"}
)

-- Material Science 3
move_technology(
	"artillery-shell-speed-7",
	{"se-material-science-pack-3"},
	{"military-science-pack","se-rocket-science-pack","se-material-science-pack-3"},
	{"kr-matter-tech-card","kr-advanced-tech-card","kr-singularity-tech-card"},
	{"matter-tech-card","advanced-tech-card","singularity-tech-card"}
)

-- Advanced Tech Card
move_technology(
	"artillery-shell-speed-8",
	{"kr-advanced-tech-card"},
	{"military-science-pack","se-rocket-science-pack","advanced-tech-card","se-material-science-pack-3"},
	{"kr-matter-tech-card","kr-singularity-tech-card","se-material-science-pack-4"},
	{"matter-tech-card","singularity-tech-card"}
)

-- Material Science 4
move_technology(
	"artillery-shell-speed-9",
	{"se-material-science-pack-4"},
	{"military-science-pack","se-rocket-science-pack","se-material-science-pack-4"},
	{"kr-matter-tech-card","kr-singularity-tech-card","se-deep-space-science-pack-1"},
	{"matter-tech-card","singularity-tech-card","se-deep-space-science-pack-1"}
)

-- Deep Space Science 1
move_technology(
	"artillery-shell-speed-10",
	{"se-deep-space-science-pack-1"},
	{"military-science-pack","se-rocket-science-pack","se-deep-space-science-pack-1","se-material-science-pack-4"},
	{"kr-matter-tech-card","kr-singularity-tech-card"},
	{"matter-tech-card","singularity-tech-card"}
)

---- Re-integrate Energy Science into Energy Weapons Damage research
move_technology(
	"energy-weapons-damage-5",
	{"se-rocket-science-pack"},
	{"production-science-pack","se-rocket-science-pack"},
	nil,
	{"automation-science-pack","logistic-science-pack","chemical-science-pack"}
)

-- Energy Science 1
move_technology(
	"energy-weapons-damage-6",
	{"se-energy-science-pack-1"},
	{"production-science-pack","se-rocket-science-pack","se-energy-science-pack-1"},
	nil,
	{"automation-science-pack","logistic-science-pack","chemical-science-pack"}
)

-- Optimization Tech Card
move_technology(
	"energy-weapons-damage-7",
	{"space-science-pack"},
	{"production-science-pack","se-rocket-science-pack","space-science-pack","se-energy-science-pack-1"},
	{"se-energy-science-pack-2"},
	{"automation-science-pack","logistic-science-pack","chemical-science-pack"}
)

-- Energy Science 2
move_technology(
	"energy-weapons-damage-8",
	{"se-energy-science-pack-2"},
	{"production-science-pack","se-rocket-science-pack","space-science-pack","se-energy-science-pack-2"},
	{"se-energy-science-pack-3"},
	{"automation-science-pack","logistic-science-pack","chemical-science-pack"}
)

-- Energy Science 3
move_technology(
	"energy-weapons-damage-9",
	{"se-energy-science-pack-3"},
	{"military-science-pack","production-science-pack","se-rocket-science-pack","space-science-pack","se-energy-science-pack-3"},
	{"se-energy-science-pack-4"},
	{"automation-science-pack","logistic-science-pack","chemical-science-pack"}
)

-- Advanced Tech Card
move_technology(
	"energy-weapons-damage-10",
	{"kr-advanced-tech-card"},
	{"military-science-pack","production-science-pack","se-rocket-science-pack","space-science-pack","advanced-tech-card","se-energy-science-pack-3"},
	{"se-deep-space-science-pack-1"},
	{"automation-science-pack","logistic-science-pack","chemical-science-pack","se-deep-space-science-pack-1"}
)

-- Energy Science 4
move_technology(
	"energy-weapons-damage-11",
	{"se-energy-science-pack-4"},
	{"se-rocket-science-pack","space-science-pack","advanced-tech-card","se-energy-science-pack-4"},
	{"se-deep-space-science-pack-2"},
	{"matter-tech-card","se-deep-space-science-pack-2"}
)

-- Deep Space Science 1
move_technology(
	"energy-weapons-damage-12",
	{"se-deep-space-science-pack-1"},
	{"se-rocket-science-pack","space-science-pack","advanced-tech-card","se-energy-science-pack-4","se-deep-space-science-pack-1"},
	nil,
	{"matter-tech-card"}
)

---- Re-integrate Biological Science into Mining Productivity
move_technology(
	"mining-productivity-4",
	{"se-rocket-science-pack"},
	{"chemical-science-pack","se-rocket-science-pack"},
	{"space-science-pack"},
	{"space-science-pack"}
)

-- Biological Science 1
move_technology(
	"mining-productivity-5",
	{"se-biological-science-pack-1"},
	{"chemical-science-pack","se-rocket-science-pack","se-biological-science-pack-1"}	
)

-- Optimization Tech Card
move_technology(
	"mining-productivity-6",
	{"space-science-pack"},
	{"chemical-science-pack","se-rocket-science-pack","space-science-pack","se-biological-science-pack-1"}
)

-- Biological Science 2
move_technology(
	"mining-productivity-7",
	{"se-biological-science-pack-2"},
	{"chemical-science-pack","se-rocket-science-pack","space-science-pack","se-biological-science-pack-2"}
)

-- Biological Science 3
move_technology(
	"mining-productivity-8",
	{"se-biological-science-pack-3"},
	{"chemical-science-pack","se-rocket-science-pack","space-science-pack","se-biological-science-pack-3"}
)

-- Advanced Tech Card
move_technology(
	"mining-productivity-9",
	{"kr-advanced-tech-card"},
	{"chemical-science-pack","se-rocket-science-pack","space-science-pack","advanced-tech-card","se-biological-science-pack-3"},
  {"se-biological-science-pack-4"}
)

-- Biological Science 4
move_technology(
	"mining-productivity-10",
	{"se-biological-science-pack-4"},
	{"chemical-science-pack","se-rocket-science-pack","space-science-pack","advanced-tech-card","se-biological-science-pack-4"},
  {"se-deep-space-science-pack-1"}
)

-- Matter Tech Card
move_technology(
	"mining-productivity-11",
	{"kr-matter-tech-card"},
	{"chemical-science-pack","se-rocket-science-pack","space-science-pack","advanced-tech-card","se-biological-science-pack-4","matter-tech-card"},
  {"se-deep-space-science-pack-2"}
)

-- Deep Space Science 1
move_technology(
	"mining-productivity-12",
	{"se-deep-space-science-pack-1"},
	{"chemical-science-pack","se-rocket-science-pack","space-science-pack","advanced-tech-card","se-biological-science-pack-4","matter-tech-card","se-deep-space-science-pack-1"},
  {"se-deep-space-science-pack-3"}
)

-- Deep Space Science 2
move_technology(
	"mining-productivity-13",
	{"se-deep-space-science-pack-2"},
	{"chemical-science-pack","se-rocket-science-pack","space-science-pack","advanced-tech-card","se-biological-science-pack-4","matter-tech-card","se-deep-space-science-pack-2"},
  {"se-deep-space-science-pack-4"}
)

-- Deep Space Science 3
move_technology(
	"mining-productivity-14",
	{"se-deep-space-science-pack-3"},
	{"chemical-science-pack","se-rocket-science-pack","space-science-pack","advanced-tech-card","se-biological-science-pack-4","matter-tech-card","se-deep-space-science-pack-3"}
)

-- Singularity Tech Card
move_technology(
	"mining-productivity-15",
	{"kr-singularity-tech-card"},
	{"chemical-science-pack","se-rocket-science-pack","space-science-pack","advanced-tech-card","se-biological-science-pack-4","matter-tech-card","se-deep-space-science-pack-3","singularity-tech-card"}
)

-- Deep Space Science 4
move_technology(
	"mining-productivity-16",
	{"se-deep-space-science-pack-4"},
	{"chemical-science-pack","se-rocket-science-pack","space-science-pack","advanced-tech-card","se-biological-science-pack-4","matter-tech-card","se-deep-space-science-pack-4","singularity-tech-card"}
)

---- Re-integrate Energy Science into Worker Robots Speed
move_technology(
	"worker-robots-speed-3",
	{"se-rocket-science-pack"},
	{"utility-science-pack","se-rocket-science-pack"},
	{"space-science-pack"},
	{"space-science-pack"}
)

-- Energy Science 1
move_technology(
	"worker-robots-speed-4",
	{"se-energy-science-pack-1"},
	{"utility-science-pack","se-rocket-science-pack","se-energy-science-pack-1"},
  {"space-science-pack"},
  {"space-science-pack"}
)

-- Optimization Tech Card
move_technology(
	"worker-robots-speed-5",
	{"space-science-pack"},
	{"se-rocket-science-pack","se-energy-science-pack-1","space-science-pack"},
	{"utility-science-pack"}
)

-- Energy Science 2
move_technology(
	"worker-robots-speed-6",
	{"se-energy-science-pack-2"},
	{"se-rocket-science-pack","se-energy-science-pack-2"}
)

-- Energy Science 3
move_technology(
	"worker-robots-speed-7",
	{"se-energy-science-pack-3"},
	{"se-rocket-science-pack","se-energy-science-pack-3"},
	{"kr-advanced-tech-card"},
	{"advanced-tech-card","matter-tech-card"}
)

-- Advanced Tech Card
move_technology(
	"worker-robots-speed-8",
	{"kr-advanced-tech-card"},
	{"se-rocket-science-pack","se-energy-science-pack-3"},
	nil,
	{"matter-tech-card"}
)

-- Energy Science 4
move_technology(
	"worker-robots-speed-9",
	{"se-energy-science-pack-4"},
	{"se-rocket-science-pack","se-energy-science-pack-4"},
	{"kr-singularity-tech-card"},
	{"matter-tech-card","singularity-tech-card"}
)

-- Deep Space Science 1
move_technology(
	"worker-robots-speed-10",
	{"se-deep-space-science-pack-1"},
	{"se-rocket-science-pack","se-energy-science-pack-4","se-deep-space-science-pack-1"},
	nil,
	{"matter-tech-card","singularity-tech-card"}
)

---- Re-integrate Material Science into Projectile Physical Damage
move_technology(
	"physical-projectile-damage-5",
	{"utility-science-pack","production-science-pack","se-rocket-science-pack"},
	{"utility-science-pack","production-science-pack","se-rocket-science-pack"},
	nil,
	{"automation-science-pack","logistic-science-pack","chemical-science-pack"}
)

-- Material Science 1
move_technology(
	"physical-projectile-damage-6",
	nil,
	{"production-science-pack","se-rocket-science-pack"},
	{"utility-science-pack"},
	{"automation-science-pack","logistic-science-pack","chemical-science-pack"}
)

-- Optimization Tech Card
move_technology(
	"physical-projectile-damage-7",
	{"space-science-pack"},
	{"production-science-pack","se-rocket-science-pack","space-science-pack"},
	{"se-material-science-pack-2"},
	{"automation-science-pack","logistic-science-pack","chemical-science-pack"}
)

-- Material Science 2
move_technology(
	"physical-projectile-damage-8",
	{"se-material-science-pack-2"},
	{"production-science-pack","se-rocket-science-pack","space-science-pack","se-material-science-pack-2"},
	{"se-material-science-pack-3"},
	{"automation-science-pack","logistic-science-pack","chemical-science-pack"}
)

-- Material Science 3
move_technology(
	"physical-projectile-damage-9",
	{"se-material-science-pack-3"},
	{"production-science-pack","se-rocket-science-pack","space-science-pack","se-material-science-pack-3"},
	{"se-material-science-pack-4"},
	{"automation-science-pack","logistic-science-pack","chemical-science-pack"}
)

-- Advanced Tech Card
move_technology(
	"physical-projectile-damage-10",
	{"kr-advanced-tech-card"},
	{"production-science-pack","se-rocket-science-pack","space-science-pack","se-material-science-pack-3","advanced-tech-card"},
	{"se-deep-space-science-pack-1"},
	{"automation-science-pack","logistic-science-pack","chemical-science-pack","se-deep-space-science-pack-1"}
)

-- Material Science 4
move_technology(
	"physical-projectile-damage-11",
	{"se-material-science-pack-4"},
	{"military-science-pack","se-rocket-science-pack","se-material-science-pack-4"},
	{"se-deep-space-science-pack-2"},
	{"matter-tech-card","se-deep-space-science-pack-2"}
)

-- Deep Space Science 1
move_technology(
	"physical-projectile-damage-12",
	{"se-deep-space-science-pack-1"},
	{"military-science-pack","se-rocket-science-pack","se-material-science-pack-4","se-deep-space-science-pack-1"},
	nil,
	{"matter-tech-card"}
)

---- Re-integrate Material Science into Refined Flammables
data_util.tech_remove_prerequisites("refined-flammables-4",{"utility-science-pack"})
data_util.tech_remove_ingredients("refined-flammables-4",{"utility-science-pack"})
move_technology(
	"refined-flammables-5",
	{"utility-science-pack","production-science-pack","se-rocket-science-pack"},
	{"production-science-pack","se-rocket-science-pack"},
	nil,
	{"automation-science-pack","logistic-science-pack","chemical-science-pack"}
)

-- Material Science 1
move_technology(
	"refined-flammables-6",
	nil,
	{"production-science-pack","se-rocket-science-pack",},
	nil,
	{"automation-science-pack","logistic-science-pack","chemical-science-pack"}
)

-- Optimization Tech Card
move_technology(
	"refined-flammables-7",
	{"space-science-pack"},
	{"production-science-pack","se-rocket-science-pack","space-science-pack"},
	{"se-material-science-pack-2"},
	{"automation-science-pack","logistic-science-pack","chemical-science-pack"}
)

-- Material Science 2
move_technology(
	"refined-flammables-8",
	{"se-material-science-pack-2"},
	{"production-science-pack","se-rocket-science-pack","space-science-pack","se-material-science-pack-2"},
	{"se-material-science-pack-3"},
	{"automation-science-pack","logistic-science-pack","chemical-science-pack"}
)

-- Material Science 3
move_technology(
	"refined-flammables-9",
	{"se-material-science-pack-3"},
	{"production-science-pack","se-rocket-science-pack","space-science-pack","se-material-science-pack-3"},
	{"se-material-science-pack-4"},
	{"automation-science-pack","logistic-science-pack","chemical-science-pack"}
)

-- Advanced Tech Card
move_technology(
	"refined-flammables-10",
	{"kr-advanced-tech-card"},
	{"production-science-pack","se-rocket-science-pack","space-science-pack","se-material-science-pack-3","advanced-tech-card"},
	{"se-deep-space-science-pack-1"},
	{"automation-science-pack","logistic-science-pack","chemical-science-pack","se-deep-space-science-pack-1"}
)

-- Material Science 4
move_technology(
	"refined-flammables-11",
	{"se-material-science-pack-4"},
	{"military-science-pack","se-rocket-science-pack","se-material-science-pack-4"},
	{"se-deep-space-science-pack-2"},
	{"matter-tech-card","se-deep-space-science-pack-2"}
)

-- Deep Space Pack 1
move_technology(
	"refined-flammables-12",
	{"se-deep-space-science-pack-1"},
	{"military-science-pack","se-rocket-science-pack","se-material-science-pack-4","se-deep-space-science-pack-1"},
	nil,
	{"matter-tech-card"}
)

---- Re-integrate Material Science into Stronger Explosives
data_util.tech_remove_prerequisites("stronger-explosives-4",{"utility-science-pack"})
data_util.tech_remove_ingredients("stronger-explosives-4",{"utility-science-pack"})
move_technology(
	"stronger-explosives-5",
	{"utility-science-pack","production-science-pack","se-rocket-science-pack"},
	{"production-science-pack","se-rocket-science-pack"},
	nil,
	{"automation-science-pack","logistic-science-pack","chemical-science-pack"}
)

-- Material Pack 1
move_technology(
	"stronger-explosives-6",
	nil,
	{"production-science-pack","se-rocket-science-pack"},
	nil,
	{"automation-science-pack","logistic-science-pack","chemical-science-pack"}
)

-- Optimization Tech Card
move_technology(
	"stronger-explosives-7",
	{"space-science-pack"},
	{"production-science-pack","se-rocket-science-pack","space-science-pack"},
	{"se-material-science-pack-2"},
	{"automation-science-pack","logistic-science-pack","chemical-science-pack"}
)

-- Material Pack 2
move_technology(
	"stronger-explosives-8",
	{"se-material-science-pack-2"},
	{"production-science-pack","se-rocket-science-pack","space-science-pack","se-material-science-pack-2"},
	{"se-material-science-pack-3"},
	{"automation-science-pack","logistic-science-pack","chemical-science-pack"}
)

-- Material Pack 3
move_technology(
	"stronger-explosives-9",
	{"se-material-science-pack-3"},
	{"production-science-pack","se-rocket-science-pack","space-science-pack","se-material-science-pack-3"},
	{"se-material-science-pack-4"},
	{"automation-science-pack","logistic-science-pack","chemical-science-pack"}
)

-- Advanced Tech Card
move_technology(
	"stronger-explosives-10",
	{"kr-advanced-tech-card"},
	{"production-science-pack","se-rocket-science-pack","space-science-pack","se-material-science-pack-3","advanced-tech-card"},
	{"se-deep-space-science-pack-1"},
	{"automation-science-pack","logistic-science-pack","chemical-science-pack","se-deep-space-science-pack-1"}
)

-- Material Pack 4
move_technology(
	"stronger-explosives-11",
	{"se-material-science-pack-4"},
	{"military-science-pack","se-rocket-science-pack","se-material-science-pack-4"},
	{"se-deep-space-science-pack-2"},
	{"matter-tech-card","se-deep-space-science-pack-2"}
)

-- Deep Space Pack 1
move_technology(
	"stronger-explosives-12",
	{"se-deep-space-science-pack-1"},
	{"military-science-pack","se-rocket-science-pack","se-material-science-pack-4","se-deep-space-science-pack-1"},
	nil,
	{"matter-tech-card"}
)

---- Re-integrate Material Science into Follower Robot Count
move_technology(
	"follower-robot-count-5",
	{"production-science-pack","se-rocket-science-pack"},
	{"production-science-pack","se-rocket-science-pack"},
	nil,
	{"automation-science-pack","logistic-science-pack","chemical-science-pack"}
)

-- Material Pack 1
move_technology(
	"follower-robot-count-6",
	nil,
	{"production-science-pack","se-rocket-science-pack"},
	nil,
	{"automation-science-pack","logistic-science-pack","chemical-science-pack"}
)

-- Optimization Tech Card
move_technology(
	"follower-robot-count-7",
	{"space-science-pack"},
	{"se-rocket-science-pack","space-science-pack","se-material-science-pack-1"},
	{"production-science-pack","se-material-science-pack-2"},
	{"automation-science-pack","logistic-science-pack","chemical-science-pack"}
)

-- Material Pack 2
move_technology(
	"follower-robot-count-8",
	{"se-material-science-pack-2"},
	{"military-science-pack","se-rocket-science-pack","se-material-science-pack-2"},
	{"kr-advanced-tech-card","se-material-science-pack-3"},
	{"matter-tech-card","advanced-tech-card"}
)

-- Material Pack 3
move_technology(
	"follower-robot-count-9",
	{"se-material-science-pack-3"},
	{"military-science-pack","se-rocket-science-pack","se-material-science-pack-3"},
	{"kr-singularity-tech-card","se-material-science-pack-4"},
	{"matter-tech-card","advanced-tech-card","singularity-tech-card"}
)

-- Advanced Tech Card
move_technology(
	"follower-robot-count-10",
	{"kr-advanced-tech-card"},
	{"military-science-pack","se-rocket-science-pack","se-material-science-pack-3"},
	{"se-deep-space-science-pack-1"},
	{"matter-tech-card","se-deep-space-science-pack-1","singularity-tech-card"}
)

-- Material Pack 4
move_technology(
	"follower-robot-count-11",
	{"se-material-science-pack-4"},
	{"military-science-pack","se-rocket-science-pack","se-material-science-pack-4"},
	{"se-deep-space-science-pack-1"},
	{"matter-tech-card","se-deep-space-science-pack-1","singularity-tech-card"}
)

-- Deep Space Pack 1
move_technology(
	"follower-robot-count-12",
	{"se-deep-space-science-pack-1"},
	{"military-science-pack","se-rocket-science-pack","se-material-science-pack-4","se-deep-space-science-pack-1"},
	nil,
	{"matter-tech-card","singularity-tech-card"}
)

---- Integrate K2 Science into Spaceship Structural Integrity
-- Optimization Tech Card
move_technology(
  "se-spaceship-integrity-2",
  {"space-science-pack"},
  {"space-science-pack"}
)

move_technology(
  "se-spaceship-integrity-3",
  nil,
  {"space-science-pack"}
)

move_technology(
  "se-spaceship-integrity-4",
  nil,
  {"space-science-pack"}
)

move_technology(
  "se-spaceship-integrity-5",
  nil,
  {"space-science-pack"}
)

-- Advanced Tech Card
move_technology(
  "se-spaceship-integrity-6",
  {"kr-advanced-tech-card"},
  {"space-science-pack","advanced-tech-card"}
)

move_technology(
  "se-spaceship-integrity-7",
  nil,
  {"space-science-pack","advanced-tech-card"},
  nil,
  {"matter-tech-card"}
)

-- Matter Tech Card
move_technology(
  "se-factory-spaceship-1",
  {"kr-matter-tech-card"},
  {"space-science-pack","advanced-tech-card"}
)

move_technology(
  "se-factory-spaceship-2",
  nil,
  {"space-science-pack","advanced-tech-card"}
)

move_technology(
  "se-factory-spaceship-3",
  nil,
  {"space-science-pack","advanced-tech-card"}
)

move_technology(
  "se-factory-spaceship-4",
  nil,
  {"space-science-pack","advanced-tech-card"}
)

-- Singularity Tech Card
move_technology(
  "se-factory-spaceship-5",
  {"kr-singularity-tech-card"},
  {"space-science-pack","advanced-tech-card","singularity-tech-card"}
)