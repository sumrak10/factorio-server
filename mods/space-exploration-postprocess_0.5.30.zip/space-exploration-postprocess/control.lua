local diagnostics = require("diagnostics")

function print_diagnostics()
  local diagnostics_message = diagnostics.get_message(script.active_mods)
  if diagnostics_message then
    game.print("[color=yellow]" ..diagnostics_message.. "[/color]")
  end
end

script.on_configuration_changed(print_diagnostics)
script.on_event(defines.events.on_player_created, print_diagnostics)
script.on_nth_tick(3600, print_diagnostics)
