--[[ Copyright (c) 2017 Optera
 * Part of Storage Tank mk2
 *
 * See LICENSE.md in the project directory for license information.
--]]

require("prototypes.technology")
require("prototypes.recipe")
require("prototypes.entity")
require("prototypes.item")

