require('prototypes.items')
require('prototypes.shortcuts')
require('prototypes.hotkeys')
