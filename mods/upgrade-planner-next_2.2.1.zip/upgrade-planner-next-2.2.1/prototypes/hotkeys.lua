data:extend{
  {type = "custom-input", name = "upgrade-planner", key_sequence = "U"},
  {
    type = "custom-input",
    name = "upgrade-planner-hide",
    key_sequence = "CONTROL + U",
  },
}
