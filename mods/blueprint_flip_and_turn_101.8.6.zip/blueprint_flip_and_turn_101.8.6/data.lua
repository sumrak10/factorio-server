require("prototypes.hotkeys")
require("prototypes.style")