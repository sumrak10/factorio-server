data:extend({
  {
    type = "custom-input",
    name = "blueprint_hotkey_flip_horizontal",
    key_sequence = "SHIFT + Z",
  },
  {
    type = "custom-input",
    name = "blueprint_hotkey_flip_vertical",
    key_sequence = "SHIFT + X",
  },
  {
    type = "custom-input",
    name = "blueprint_hotkey_reverse_inserters",
    key_sequence = "SHIFT + C",
  },
})
