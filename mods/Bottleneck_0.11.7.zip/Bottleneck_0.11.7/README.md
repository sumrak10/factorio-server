# Bottleneck

Factorio mod that tell you which machines are starved of ingredients

## Attributions

The Thumbnail icon has been adopted from the [bottleneck](https://thenounproject.com/Stephen_Plaster/collection/flow-states/?i=366717) icon created by [Stephen Plaster](https://thenounproject.com/Stephen_Plaster/) licenced under [CCBY 3.0](https://creativecommons.org/licenses/by/3.0/us/legalcode).
Icons based of off [Feather](https://github.com/feathericons/feather).
