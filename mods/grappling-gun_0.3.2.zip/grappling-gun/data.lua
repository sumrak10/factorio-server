require("prototypes/entity/weapon-grappling")
require("prototypes/item/weapon-grappling")
require("prototypes/recipe/weapon-grappling")
require("prototypes/technology/weapon-grappling")
