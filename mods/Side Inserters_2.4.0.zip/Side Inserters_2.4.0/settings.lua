data:extend({
  {
    type = "bool-setting",
    name = "side-inserters-wrap",
    setting_type = "runtime-per-user",
    default_value = true
  },
  {
    type = "bool-setting",
    name = "side-inserters-45",
    setting_type = "runtime-global",
    default_value = false
  }
})